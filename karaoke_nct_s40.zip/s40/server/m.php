<?php
// Dat tai /api/m.php. Phai truy cap duoc bang HTTP thuong (khong ep HTTPS) vi S40 doi cu khong co TLS moi.
include '../incfiles/connect.php';
header('Content-Type: text/plain; charset=utf-8');

function cl($s){ return trim(str_replace(array("\t","\r","\n"),' ',(string)$s)); }

// Giai ma loi NCT: port tu decode_nct() trong js (RC4, key "Lyr1cjust4nct", du lieu la chuoi hex)
function rc4($key,$data){
  $s=range(0,255); $j=0; $kl=strlen($key);
  for($i=0;$i<256;$i++){ $j=($j+$s[$i]+ord($key[$i%$kl]))&255; $t=$s[$i];$s[$i]=$s[$j];$s[$j]=$t; }
  $i=$j=0; $out='';
  for($n=0;$n<strlen($data);$n++){
    $i=($i+1)&255; $j=($j+$s[$i])&255; $t=$s[$i];$s[$i]=$s[$j];$s[$j]=$t;
    $out.=chr(ord($data[$n])^$s[($s[$i]+$s[$j])&255]);
  }
  return $out;
}
function fixLyric($l){
  $l=trim((string)$l);
  if($l!=='' && !preg_match('/\s/',$l) && ctype_xdigit($l) && strlen($l)%2==0) $l=rc4('Lyr1cjust4nct',hex2bin($l));
  $l=preg_replace('/<br\s*\/?>/i',"\n",$l);
  return str_replace("\r","",strip_tags($l));
}

$a=isset($_GET['a'])?$_GET['a']:'';

if($a=='chart'){            // moi dong: id \t ten \t ca si
  ob_start(); $res=bxhnct(); ob_end_clean();   // bxhnct() co echo $sig de debug -> chan lai
  if(empty($res['data'])) exit;
  foreach($res['data'] as $d) echo cl($d['id'])."\t".cl($d['name'])."\t".cl($d['singer'])."\n";

}elseif($a=='search'){
  $res=searchnct(isset($_GET['q'])?$_GET['q']:'');
  if(empty($res['data'])) exit;
  foreach($res['data'] as $d) echo cl($d['id'])."\t".cl($d['name'])."\t".cl($d['artist'])."\n";

}elseif($a=='song'){        // dong1=ten, dong2=ca si, tu dong3 tro di = loi (LRC)
  $res=songNCT(isset($_GET['id'])?$_GET['id']:'',1);
  if(!empty($res['err'])) exit;
  $d=$res['data'];
  echo cl($d['name'])."\n".cl($d['artists'])."\n".fixLyric($d['lyric']);

}elseif($a=='stream'){      // proxy mp3 qua HTTP, co Range
  $res=songNCT(isset($_GET['id'])?$_GET['id']:'',null);
  if(!empty($res['err'])){ http_response_code(404); exit; }
  $link=$res['data']['link'];
  $url=isset($link[128])?$link[128]:reset($link);
  if(!$url){ http_response_code(404); exit; }
  header('Content-Type: audio/mpeg');
  $h=array(); if(isset($_SERVER['HTTP_RANGE'])) $h[]='Range: '.$_SERVER['HTTP_RANGE'];
  $ch=curl_init($url);
  curl_setopt_array($ch,array(
    CURLOPT_HTTPHEADER=>$h, CURLOPT_FOLLOWLOCATION=>1, CURLOPT_SSL_VERIFYPEER=>0, CURLOPT_SSL_VERIFYHOST=>0,
    CURLOPT_HEADERFUNCTION=>function($c,$l){
      if(preg_match('/^HTTP\/[\d.]+ (\d+)/i',$l,$m)) http_response_code((int)$m[1]);
      elseif(preg_match('/^(Content-Length|Content-Range|Accept-Ranges):/i',$l)) header(trim($l));
      return strlen($l);
    },
    CURLOPT_WRITEFUNCTION=>function($c,$d){ echo $d; flush(); return strlen($d); }
  ));
  curl_exec($ch); curl_close($ch);
}
