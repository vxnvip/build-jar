import java.io.*;
import java.util.Vector;
import javax.microedition.io.*;
import javax.microedition.lcdui.StringItem;

public class Net {
    // PHAI la http:// (S40 doi cu khong ho tro TLS hien dai)
    public static final String BASE = "http://mp3.nguyenvip.pro/api/m.php";

    public static String get(String url) throws IOException {
        HttpConnection c = null; InputStream in = null;
        try {
            c = (HttpConnection) Connector.open(url);
            c.setRequestMethod(HttpConnection.GET);
            in = c.openInputStream();
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[1024]; int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return new String(o.toByteArray(), "UTF-8");
        } finally {
            try { if (in != null) in.close(); } catch (Exception e) {}
            try { if (c != null) c.close(); } catch (Exception e) {}
        }
    }

    /** Tai nguyen file ve RAM (theo redirect toi da 4 lan). prog != null thi cap nhat chu tien do. */
    public static byte[] getBytes(String url, StringItem prog) throws IOException {
        for (int hop = 0; hop < 5; hop++) {
            HttpConnection c = null; InputStream in = null;
            try {
                c = (HttpConnection) Connector.open(url);
                c.setRequestMethod(HttpConnection.GET);
                int code = c.getResponseCode();
                if (code == 301 || code == 302 || code == 303 || code == 307) {
                    String loc = c.getHeaderField("Location");
                    if (loc == null || loc.length() == 0) throw new IOException("Redirect khong co Location");
                    url = loc;
                    continue;
                }
                if (code != 200) throw new IOException("HTTP " + code);
                long len = c.getLength();
                in = c.openInputStream();
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                byte[] b = new byte[4096]; int n; int total = 0, lastShown = 0;
                while ((n = in.read(b)) > 0) {
                    o.write(b, 0, n);
                    total += n;
                    if (prog != null && total - lastShown >= 65536) {
                        lastShown = total;
                        prog.setText("Tai mp3: " + (total / 1024) + (len > 0 ? "/" + (len / 1024) : "") + " KB");
                    }
                }
                if (total == 0) throw new IOException("File rong");
                return o.toByteArray();
            } finally {
                try { if (in != null) in.close(); } catch (Exception e) {}
                try { if (c != null) c.close(); } catch (Exception e) {}
            }
        }
        throw new IOException("Qua nhieu redirect");
    }

    /** percent-encode UTF-8 */
    public static String enc(String s) {
        try {
            byte[] b = s.getBytes("UTF-8");
            StringBuffer o = new StringBuffer();
            for (int i = 0; i < b.length; i++) {
                int c = b[i] & 255;
                if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '-' || c == '_' || c == '.')
                    o.append((char) c);
                else { o.append('%'); o.append("0123456789ABCDEF".charAt(c >> 4)); o.append("0123456789ABCDEF".charAt(c & 15)); }
            }
            return o.toString();
        } catch (Exception e) { return ""; }
    }

    public static Vector split(String s, char sep) {
        Vector v = new Vector(); int st = 0;
        for (int i = 0; i <= s.length(); i++)
            if (i == s.length() || s.charAt(i) == sep) { v.addElement(s.substring(st, i)); st = i + 1; }
        return v;
    }
}
