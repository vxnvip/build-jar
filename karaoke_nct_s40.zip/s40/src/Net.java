import java.io.*;
import java.util.Vector;
import javax.microedition.io.*;

public class Net {
    // PHAI la http:// (S40 doi cu khong ho tro TLS hien dai)
    public static final String BASE = "http://mp3.nguyenvip.pro/api/m.php";

    public static String get(String url) throws IOException {
        HttpConnection c = null; InputStream in = null;
        try {
            c = (HttpConnection) Connector.open(url);
            c.setRequestMethod(HttpConnection.GET);
            in = c.openInputStream();
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[1024]; int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return new String(o.toByteArray(), "UTF-8");
        } finally {
            try { if (in != null) in.close(); } catch (Exception e) {}
            try { if (c != null) c.close(); } catch (Exception e) {}
        }
    }

    /** percent-encode UTF-8 */
    public static String enc(String s) {
        try {
            byte[] b = s.getBytes("UTF-8");
            StringBuffer o = new StringBuffer();
            for (int i = 0; i < b.length; i++) {
                int c = b[i] & 255;
                if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '-' || c == '_' || c == '.')
                    o.append((char) c);
                else { o.append('%'); o.append("0123456789ABCDEF".charAt(c >> 4)); o.append("0123456789ABCDEF".charAt(c & 15)); }
            }
            return o.toString();
        } catch (Exception e) { return ""; }
    }

    public static Vector split(String s, char sep) {
        Vector v = new Vector(); int st = 0;
        for (int i = 0; i <= s.length(); i++)
            if (i == s.length() || s.charAt(i) == sep) { v.addElement(s.substring(st, i)); st = i + 1; }
        return v;
    }
}
