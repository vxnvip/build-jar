import java.util.Vector;

/** Port nguyen logic karaoke trong js/play.js: parseLRC, findIndexAtTime, pctInLine. Don vi: ms. */
public class Lrc {
    public int[] time = new int[0];
    public String[] text = new String[0];
    public int n = 0;
    public int dur = 0;      // do dai bai (ms), 0 = chua biet
    private int last = -1;   // lastIdx

    // ===== parseLRC =====
    public static Lrc parse(String raw, int durationMs) {
        Lrc l = new Lrc();
        l.dur = durationMs;
        if (raw == null) return l;
        raw = stripHtml(raw).trim();
        if (raw.length() == 0) return l;

        Vector ts = new Vector(), tx = new Vector();
        Vector lines = splitLines(raw);
        for (int i = 0; i < lines.size(); i++) {
            String line = ((String) lines.elementAt(i)).trim();
            if (line.length() == 0) continue;
            Vector tags = new Vector();
            StringBuffer content = new StringBuffer();
            int p = 0;
            while (p < line.length()) {
                char c = line.charAt(p);
                if (c == '[') {
                    int e = line.indexOf(']', p);
                    int t = (e > 0) ? tag(line.substring(p + 1, e)) : -1;
                    if (t >= 0) { tags.addElement(new Integer(t)); p = e + 1; continue; }
                }
                content.append(c);
                p++;
            }
            if (tags.size() == 0) continue;            // dong khong co moc thoi gian -> bo (giong web)
            String s = content.toString().trim();
            if (s.length() == 0) continue;             // playz8: dong rong thi bo
            for (int k = 0; k < tags.size(); k++) { ts.addElement(tags.elementAt(k)); tx.addElement(s); }
        }

        if (ts.size() > 0) {
            int m = ts.size();
            l.time = new int[m]; l.text = new String[m]; l.n = m;
            for (int i = 0; i < m; i++) { l.time[i] = ((Integer) ts.elementAt(i)).intValue(); l.text[i] = (String) tx.elementAt(i); }
            // sort on dinh theo time (insertion sort)
            for (int i = 1; i < m; i++) {
                int t = l.time[i]; String s = l.text[i]; int j = i - 1;
                while (j >= 0 && l.time[j] > t) { l.time[j + 1] = l.time[j]; l.text[j + 1] = l.text[j]; j--; }
                l.time[j + 1] = t; l.text[j + 1] = s;
            }
            return l;
        }

        // fallback: chia deu cac dong theo do dai bai (mac dinh 180s)
        Vector simple = new Vector();
        for (int i = 0; i < lines.size(); i++) {
            String s = ((String) lines.elementAt(i)).trim();
            if (s.length() > 0) simple.addElement(s);
        }
        int m = simple.size();
        if (m == 0) return l;
        int dur = (durationMs > 0 ? durationMs : 180000) / m;
        l.time = new int[m]; l.text = new String[m]; l.n = m;
        for (int i = 0; i < m; i++) { l.time[i] = i * dur; l.text[i] = (String) simple.elementAt(i); }
        return l;
    }

    /** "mm:ss" hoac "mm:ss.xx" -> ms, hoac -1 neu khong phai moc thoi gian */
    private static int tag(String s) {
        int c = s.indexOf(':');
        if (c <= 0) return -1;
        int dot = s.indexOf('.', c);
        String a = s.substring(0, c);
        String b = (dot < 0) ? s.substring(c + 1) : s.substring(c + 1, dot);
        String f = (dot < 0) ? "" : s.substring(dot + 1);
        if (!digits(a) || !digits(b) || (dot >= 0 && !digits(f))) return -1;
        int ms = 0;
        if (f.length() == 1) ms = Integer.parseInt(f) * 100;
        else if (f.length() == 2) ms = Integer.parseInt(f) * 10;
        else if (f.length() >= 3) ms = Integer.parseInt(f.substring(0, 3));
        return (Integer.parseInt(a) * 60 + Integer.parseInt(b)) * 1000 + ms;
    }

    private static boolean digits(String s) {
        if (s.length() == 0) return false;
        for (int i = 0; i < s.length(); i++) { char c = s.charAt(i); if (c < '0' || c > '9') return false; }
        return true;
    }

    private static Vector splitLines(String s) {
        Vector v = new Vector();
        int st = 0;
        for (int i = 0; i <= s.length(); i++) {
            if (i == s.length() || s.charAt(i) == '\n') {
                String x = s.substring(st, i);
                if (x.endsWith("\r")) x = x.substring(0, x.length() - 1);
                v.addElement(x);
                st = i + 1;
            }
        }
        return v;
    }

    /** <br> -> \n, bo the HTML, &nbsp; -> khoang trang */
    private static String stripHtml(String s) {
        StringBuffer o = new StringBuffer();
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '<') {
                int e = s.indexOf('>', i);
                if (e < 0) break;
                String tg = s.substring(i + 1, e).trim().toLowerCase();
                if (tg.startsWith("br")) o.append('\n');
                i = e + 1;
            } else if (c == '&' && s.startsWith("&nbsp;", i)) { o.append(' '); i += 6; }
            else { o.append(c); i++; }
        }
        return o.toString();
    }

    // ===== findIndexAtTime (co cache lastIdx + binary search, y het web) =====
    public int find(int t) {
        if (n == 0) return -1;
        if (last >= 0 && last < n - 1 && t >= time[last] && t < time[last + 1]) return last;
        int lo = 0, hi = n - 1;
        if (t < time[0]) return 0;
        while (lo <= hi) {
            int mid = (lo + hi) >> 1;
            int cur = time[mid];
            int next = (mid + 1 < n) ? time[mid + 1] : cur + 5000;
            if (t >= cur && t < next) { last = mid; return mid; }
            if (t < cur) hi = mid - 1; else lo = mid + 1;
        }
        return n - 1;
    }

    // ===== pctInLine (playz8): dong cuoi lay den het bai; to xong som 0.2s truoc dong ke =====
    public int pct(int idx, int t) {            // tra ve 0..1000 (do phan giai 0.1%) cho muot
        if (idx < 0 || idx >= n) return 0;
        int s = time[idx];
        int e = (idx + 1 < n) ? time[idx + 1] : (dur > 0 ? dur : s + 4000);
        int adjE = e - 200;
        if (adjE <= s) return t > s ? 1000 : 0;
        int p = (int) ((long) (t - s) * 1000 / (adjE - s));
        return p < 0 ? 0 : (p > 1000 ? 1000 : p);
    }

    /** thoi diem ket thuc dong idx (dung cho tua) */
    public int end(int idx) {
        return (idx + 1 < n) ? time[idx + 1] : (dur > 0 ? dur : time[idx] + 4000);
    }

    public String at(int i) { return (i >= 0 && i < n) ? text[i] : ""; }
}
