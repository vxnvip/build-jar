import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import javax.microedition.midlet.*;

/** Man hinh 1: nhap ID NCT -> bam PHAT -> goi api -> thanh cong thi mo karaoke va phat nhac. */
public class KaraokeMidlet extends MIDlet implements CommandListener, ItemCommandListener {
    private Display d;
    private Form form;
    private TextField idField;
    private StringItem btn;
    private KaraokeCanvas canvas;
    private boolean busy = false;

    private final Command cPlay = new Command("Phat", Command.OK, 1);
    private final Command cBack = new Command("Quay lai", Command.BACK, 1);
    private final Command cExit = new Command("Thoat", Command.EXIT, 2);

    public void startApp() {
        if (d != null) return;                       // resume: giu nguyen man hinh
        d = Display.getDisplay(this);

        canvas = new KaraokeCanvas(this);
        canvas.addCommand(cBack);
        canvas.setCommandListener(this);

        form = new Form("Karaoke NCT");
        idField = new TextField("ID bai hat NCT", "", 40, TextField.ANY);
        btn = new StringItem(null, "PHAT NHAC", Item.BUTTON);
        btn.setDefaultCommand(cPlay);
        btn.setItemCommandListener(this);
        form.append(idField);
        form.append(btn);
        form.addCommand(cPlay);
        form.addCommand(cExit);
        form.setCommandListener(this);
        d.setCurrent(form);
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) { if (canvas != null) canvas.stop(); }

    public void commandAction(Command c, Displayable s) {
        if (c == cExit) { destroyApp(true); notifyDestroyed(); }
        else if (c == cBack && s == canvas) { canvas.stop(); d.setCurrent(form); }
        else if (c == cPlay) go();
    }

    public void commandAction(Command c, Item i) { go(); }     // bam nut PHAT NHAC

    private void go() {
        if (busy) return;
        final String id = idField.getString().trim();
        if (id.length() == 0) { alert("Loi", "Chua nhap ID", form); return; }
        busy = true;

        Alert wait = new Alert("", "Dang tai...", null, AlertType.INFO);
        wait.setIndicator(new Gauge(null, false, Gauge.INDEFINITE, Gauge.CONTINUOUS_RUNNING));
        wait.setTimeout(Alert.FOREVER);
        d.setCurrent(wait);

        new Thread(new Runnable() { public void run() {
            Player p = null;
            try {
                // 1) goi api JSON -> ten / ca si / loi (da giai ma) / link mp3
                Api api = Api.load(id);
                String title = api.name, artist = api.artists;
                if (api.stream.length() == 0) throw new Exception("Khong co link nhac");

                // 2) mo luong nhac (S40 cu thuong chi phat http, khong phat https)
                String url = api.stream;
                if (Api.STREAM_PROXY.length() > 0) url = Api.STREAM_PROXY + Net.enc(url);
                else if (url.startsWith("https://")) url = "http://" + url.substring(8);
                p = Manager.createPlayer(url);
                p.realize();
                p.prefetch();
                long du = p.getDuration();                   // micro-giay, co the la -1
                Lrc l = Lrc.parse(api.lyric, du > 0 ? (int) (du / 1000) : 0);

                // 3) thanh cong -> mo karaoke + phat
                d.setCurrent(canvas);
                canvas.start(p, l, title, artist);
                p = null;                                    // canvas giu va tu dong dong player
            } catch (Throwable e) {
                if (p != null) { try { p.close(); } catch (Exception x) {} }
                alert("Loi", e.getMessage() != null ? e.getMessage() : e.toString(), form);
            } finally {
                busy = false;
            }
        } }).start();
    }

    private void alert(String title, String msg, Displayable next) {
        Alert a = new Alert(title, msg, null, AlertType.ERROR);
        a.setTimeout(Alert.FOREVER);
        d.setCurrent(a, next);
    }

    /** het bai hoac loi phat -> ve man hinh nhap ID */
    public void songEnded() {
        canvas.stop();
        d.setCurrent(form);
    }
}
