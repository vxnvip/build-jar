import java.io.ByteArrayInputStream;
import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import javax.microedition.midlet.*;

/** Man hinh 1: nhap ID NCT -> bam PHAT -> goi api -> thanh cong thi mo karaoke va phat nhac. */
public class KaraokeMidlet extends MIDlet implements CommandListener, ItemCommandListener {
    private Display d;
    private Form form;
    private TextField idField;
    private StringItem btn;
    private KaraokeCanvas canvas;
    private boolean busy = false;

    private final Command cPlay = new Command("Phat", Command.OK, 1);
    private final Command cBack = new Command("Quay lai", Command.BACK, 1);
    private final Command cExit = new Command("Thoat", Command.EXIT, 2);

    public void startApp() {
        if (d != null) return;                       // resume: giu nguyen man hinh
        d = Display.getDisplay(this);

        canvas = new KaraokeCanvas(this);
        // KHONG addCommand cho canvas: neu co Command thi J2ME Loader/may that se tu ve thanh "Quay lai"
        // va chiem phim mem, lam phim mem trai khong toi KaraokeCanvas.keyPressed. Canvas tu ve phim mem.

        form = new Form("Karaoke NCT");
        idField = new TextField("ID bai hat NCT", "", 40, TextField.ANY);
        btn = new StringItem(null, "PHAT NHAC", Item.BUTTON);
        btn.setDefaultCommand(cPlay);
        btn.setItemCommandListener(this);
        form.append(idField);
        form.append(btn);
        form.addCommand(cPlay);
        form.addCommand(cExit);
        form.setCommandListener(this);
        d.setCurrent(form);
    }

    public void pauseApp() {}
    public void destroyApp(boolean u) { if (canvas != null) canvas.stop(); }

    public void commandAction(Command c, Displayable s) {
        if (c == cExit) { destroyApp(true); notifyDestroyed(); }
        else if (c == cBack && s == canvas) { canvas.stop(); d.setCurrent(form); }
        else if (c == cBack) { d.setCurrent(form); }
        else if (c == cPlay) go();
    }

    public void commandAction(Command c, Item i) { go(); }     // bam nut PHAT NHAC

    private void go() {
        if (busy) return;
        final String id = idField.getString().trim();
        if (id.length() == 0) { alert("Loi", "Chua nhap ID", form); return; }
        busy = true;

        d.setCurrent(waitForm("Dang tai..."));

        new Thread(new Runnable() { public void run() {
            Player p = null;
            try {
                // 1) goi api JSON -> ten / ca si / loi (da giai ma) / link mp3
                Api api = Api.load(id);
                waitText.setText("2/4 Tao player...");
                String title = api.name, artist = api.artists;
                if (api.stream.length() == 0) throw new Exception("Khong co link nhac");

                // 2) mo luong nhac (giu nguyen https; neu may S40 that khong phat duoc thi dung STREAM_PROXY)
                String url = api.stream;
                if (Api.STREAM_PROXY.length() > 0) url = Api.STREAM_PROXY + Net.enc(url);
                if (Api.DOWNLOAD_FIRST) {
                    p = fromBytes(url);
                } else {
                    // giong ZingMp3: createPlayer(url) -> tai dan, phat ngay
                    waitText.setText("3/5 Mo luong nhac...");
                    try {
                        p = openStream(url);
                    } catch (Exception e1) {
                        p = null;
                        if (url.startsWith("https://")) {          // S40 cu: thu lai bang http
                            try { p = openStream("http://" + url.substring(8)); } catch (Exception e2) { p = null; }
                        }
                        if (p == null) p = fromBytes(url);           // cuoi cung: tai het ve RAM
                    }
                }
                waitText.setText("5/5 Realize + prefetch...");
                p.realize();
                p.prefetch();
                long du = p.getDuration();                   // micro-giay, co the la -1
                Lrc l = Lrc.parse(api.lyric, du > 0 ? (int) (du / 1000) : 0);

                // anh bia cho dia (loi thi dung anh mac dinh)
                canvas.setCover(loadCover(api.thumb));

                // 3) thanh cong -> mo karaoke + phat
                d.setCurrent(canvas);
                canvas.setLyricText(api.plain);
                canvas.start(p, l, title, artist);
                p = null;                                    // canvas giu va tu dong dong player
            } catch (Throwable e) {
                if (p != null) { try { p.close(); } catch (Exception x) {} }
                alert("Loi", e.getMessage() != null ? e.getMessage() : e.toString(), form);
            } finally {
                busy = false;
            }
        } }).start();
    }


    /** tai anh bia (thu url goc, loi thi thu http); tra ve null neu khong tai duoc */
    private Image loadCover(String url) {
        if (url == null || url.length() == 0) return null;
        for (int k = 0; k < 2; k++) {
            try {
                String u = (k == 0) ? url : (url.startsWith("https://") ? "http://" + url.substring(8) : null);
                if (u == null) return null;
                byte[] b = Net.getBytes(u, null);
                return Image.createImage(b, 0, b.length);
            } catch (Throwable e) {}
        }
        return null;
    }

    /** stream truc tiep tu URL: realize + prefetch de biet ngay la may co phat duoc khong */
    private Player openStream(String url) throws Exception {
        Player q = Manager.createPlayer(url);
        try {
            q.realize();
            q.prefetch();
        } catch (Exception e) {
            try { q.close(); } catch (Exception x) {}
            throw e;
        }
        return q;
    }

    /** tai het mp3 ve RAM roi tao player (duong lui) */
    private Player fromBytes(String url) throws Exception {
        waitText.setText("3/5 Tai mp3...");
        byte[] data = Net.getBytes(url, waitText);
        waitText.setText("4/5 Tao player (" + (data.length / 1024) + " KB)...");
        return Manager.createPlayer(new ByteArrayInputStream(data), "audio/mpeg");
    }

    /** Man hinh cho: dung Form thay Alert (Alert modal tren J2ME Loader se tu dong ve man cu khi bi thay the) */
    private StringItem waitText;
    private Form waitForm(String msg) {
        Form f = new Form("Karaoke NCT");
        waitText = new StringItem(null, msg);
        f.append(waitText);
        f.append(new Gauge(null, false, Gauge.INDEFINITE, Gauge.CONTINUOUS_RUNNING));
        return f;
    }

    private void alert(String title, String msg, Displayable next) {
        Alert a = new Alert(title, msg, null, AlertType.ERROR);
        a.setTimeout(Alert.FOREVER);
        d.setCurrent(a, next);
    }

    /** het bai hoac loi phat -> ve man hinh nhap ID */
    public void songEnded() {
        canvas.stop();
        d.setCurrent(form);
    }
}
