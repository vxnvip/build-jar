/** Goi api JSON cua mp3.duyquyen.site va giai ma loi NCT ngay trong app (khong can m.php). */
public class Api {
    // Endpoint tra ve {"err":0,"data":{name,artists,lyric(hex RC4),content,thumbnail,link:{"128":...}}}
    public static final String URL = "http://mp3.duyquyen.site/api/test.php";
    public static final String ID_PARAM = "id";           // ten tham so ID: URL?id=xxxx
    // S40 doi cu hay khong phat duoc https. Neu server co proxy mp3, dien vao day, vd:
    //   "http://mp3.duyquyen.site/api/stream.php?u="   (app se noi them link da encode)
    public static final String STREAM_PROXY = "";
    // true (mac dinh): tai het mp3 ve RAM roi moi phat -> chay chac tren J2ME Loader/Android.
    // false: giong ZingMp3, Manager.createPlayer(url) de may tu stream (app van tu lui ve tai RAM neu stream loi,
    //   nhung neu stream "chay" ma khong ra tieng thi phai de true).
    public static final boolean DOWNLOAD_FIRST = true;

    public String name = "", artists = "", lyric = "", stream = "", plain = "";

    public static Api load(String id) throws Exception {
        return parse(Net.get(URL + "?" + ID_PARAM + "=" + Net.enc(id)));
    }

    public static Api parse(String j) throws Exception {
        if (j.indexOf("\"err\":0") < 0 && j.indexOf("\"err\":\"0\"") < 0)
            throw new Exception("API loi hoac ID khong dung");
        Api a = new Api();
        a.name = str(j, "name", 0);
        a.artists = str(j, "artists", 0);
        int lk = j.indexOf("\"link\"");
        a.stream = (lk >= 0) ? unamp(str(j, "128", lk)) : "";
        String lyr = str(j, "lyric", 0);
        String dec = isHex(lyr) ? decodeLyric(lyr) : lyr;
        a.lyric = (dec.length() > 0) ? dec : str(j, "content", 0);   // khong co LRC thi dung loi thuong
        String content = str(j, "content", 0);                       // loi dang chu thuong (co <br>)
        a.plain = toPlain(content.length() > 0 ? content : lrcToPlain(a.lyric));
        if (a.name.length() == 0) throw new Exception("Khong co du lieu bai hat");
        return a;
    }

    /** "&amp;" -> "&" (link nhac co the bi escape HTML) */
    static String unamp(String s) {
        StringBuffer o = new StringBuffer();
        int i = 0;
        while (i < s.length()) {
            if (s.startsWith("&amp;", i)) { o.append('&'); i += 5; } else o.append(s.charAt(i++));
        }
        return o.toString();
    }

    /** <br> -> xuong dong, bo the HTML, doi vai entity thuong gap */
    static String toPlain(String s) {
        StringBuffer o = new StringBuffer();
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '<') {
                int e = s.indexOf('>', i);
                if (e < 0) break;
                String tg = s.substring(i + 1, e).trim().toLowerCase();
                if (tg.startsWith("br") || tg.startsWith("/p")) o.append('\n');
                i = e + 1;
            } else if (c == '&') {
                if (s.startsWith("&nbsp;", i)) { o.append(' '); i += 6; }
                else if (s.startsWith("&amp;", i)) { o.append('&'); i += 5; }
                else if (s.startsWith("&quot;", i)) { o.append('"'); i += 6; }
                else if (s.startsWith("&#39;", i)) { o.append('\''); i += 5; }
                else { o.append(c); i++; }
            } else if (c == '\r') i++;
            else { o.append(c); i++; }
        }
        return o.toString().trim();
    }

    /** LRC -> chu thuong: bo [mm:ss.xx] dau dong, bo dong rong */
    static String lrcToPlain(String lrc) {
        StringBuffer o = new StringBuffer();
        int st = 0;
        for (int i = 0; i <= lrc.length(); i++) {
            if (i == lrc.length() || lrc.charAt(i) == '\n') {
                String ln = lrc.substring(st, i);
                st = i + 1;
                while (ln.startsWith("[")) {
                    int e = ln.indexOf(']');
                    if (e < 0) break;
                    ln = ln.substring(e + 1);
                }
                ln = ln.trim();
                if (ln.length() > 0) o.append(ln).append('\n');
            }
        }
        return o.toString();
    }

    // ===== JSON toi thieu: lay gia tri chuoi cua "key" sau vi tri from =====
    static String str(String j, String key, int from) {
        String pat = "\"" + key + "\":";
        int p = j.indexOf(pat, from);
        if (p < 0) return "";
        p += pat.length();
        while (p < j.length() && j.charAt(p) == ' ') p++;
        if (p >= j.length() || j.charAt(p) != '"') return "";       // null / so
        p++;
        StringBuffer o = new StringBuffer();
        while (p < j.length()) {
            char c = j.charAt(p++);
            if (c == '"') break;
            if (c != '\\') { o.append(c); continue; }
            if (p >= j.length()) break;
            char e = j.charAt(p++);
            if (e == 'n') o.append('\n');
            else if (e == 'r') o.append('\r');
            else if (e == 't') o.append('\t');
            else if (e == 'u' && p + 4 <= j.length()) {
                try { o.append((char) Integer.parseInt(j.substring(p, p + 4), 16)); } catch (Exception x) {}
                p += 4;
            } else o.append(e);                                      // \" \\ \/
        }
        return o.toString();
    }

    // ===== giai ma loi NCT: RC4, key "Lyr1cjust4nct" (giong decode_nct trong js) =====
    static boolean isHex(String s) {
        if (s.length() < 2 || (s.length() & 1) != 0) return false;
        for (int i = 0; i < s.length(); i++) if (hv(s.charAt(i)) < 0) return false;
        return true;
    }

    private static int hv(char c) {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    }

    static String decodeLyric(String hex) {
        try {
            int n = hex.length() / 2;
            byte[] d = new byte[n];
            for (int i = 0; i < n; i++) d[i] = (byte) ((hv(hex.charAt(2 * i)) << 4) | hv(hex.charAt(2 * i + 1)));

            byte[] key = "Lyr1cjust4nct".getBytes();
            int[] s = new int[256];
            for (int i = 0; i < 256; i++) s[i] = i;
            int j = 0, t;
            for (int i = 0; i < 256; i++) {
                j = (j + s[i] + (key[i % key.length] & 255)) & 255;
                t = s[i]; s[i] = s[j]; s[j] = t;
            }
            int a = 0, b = 0;
            for (int k = 0; k < n; k++) {
                a = (a + 1) & 255; b = (b + s[a]) & 255;
                t = s[a]; s[a] = s[b]; s[b] = t;
                d[k] ^= (byte) s[(s[a] + s[b]) & 255];
            }
            String raw = new String(d, "UTF-8");

            // giong hexFromArray: bo \n, doi \r -> \n, xuong dong truoc '[' neu truoc do khong phai ']'
            StringBuffer o = new StringBuffer();
            for (int i = 0; i < raw.length(); i++) {
                char c = raw.charAt(i);
                if (c == '\uFEFF' || c == '\n') continue;
                if (c == '\r') { o.append('\n'); continue; }
                if (c == '[' && o.length() > 0 && o.charAt(o.length() - 1) != ']') o.append('\n');
                o.append(c);
            }
            return o.toString();
        } catch (Throwable e) {
            return "";
        }
    }
}
