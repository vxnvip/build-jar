import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import javax.microedition.media.control.VolumeControl;

/** Giao dien ZingMp3 (240x320) + 3 dong karaoke dat vao cho "Dang tai nhac...". */
public class KaraokeCanvas extends Canvas implements Runnable, PlayerListener {
    private static final int TL = Graphics.TOP | Graphics.LEFT;

    private final KaraokeMidlet app;
    private Player player;
    private Lrc lrc;
    private String title = "", artist = "";
    private int durMs = 0;
    private boolean repeat = false;
    private int flashCell = -1;
    private long flashUntil = 0;

    private int smoothT = 0;                 // ms
    private int cur = 0, pct = 0;
    private long seekedAt = 0;
    private boolean seeking = false;
    private long holdUntil = 0, seekEnd = 0, animStart = 0, animDur = 1;

    private boolean running = false, paused = false;
    private String err = "";
    private long lastWall = 0, lastDurChk = 0;
    private int lastPos = -1;
    private static final int FRAME_MS = 16;  // ~60 fps
    private Font fSmall, fBig;

    private Image imAlbum, imPrev, imPlay, imPause, imNext, imBar, imKnob, imRep, imRepOn;

    public KaraokeCanvas(KaraokeMidlet app) {
        this.app = app;
        setFullScreenMode(true);
        fSmall = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL);
        fBig = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_MEDIUM);
        imAlbum = scale(load("/defaultAlbum.png"), 60, 60);
        imRep = scale(load("/repeat.png"), 14, 14);
        imRepOn = scale(load("/repeat_over.png"), 14, 14);
        imPrev = load("/btn_prev.png");
        imPlay = load("/btn_play.png");
        imPause = load("/btn_pause.png");
        imNext = load("/btn_next.png");
        imBar = load("/bgd_slide.png");
        imKnob = load("/slider.png");
    }

    private static Image load(String p) {
        try { return Image.createImage(p); } catch (Throwable e) { return null; }
    }

    /** thu nho anh (lay mau gan nhat) - MIDP khong co scale san */
    private static Image scale(Image src, int nw, int nh) {
        if (src == null) return null;
        try {
            int ow = src.getWidth(), oh = src.getHeight();
            int[] in = new int[ow * oh];
            src.getRGB(in, 0, ow, 0, 0, ow, oh);
            int[] out = new int[nw * nh];
            for (int y = 0; y < nh; y++) {
                int sy = y * oh / nh;
                for (int x = 0; x < nw; x++) out[y * nw + x] = in[sy * ow + x * ow / nw];
            }
            return Image.createRGBImage(out, nw, nh, true);
        } catch (Throwable e) { return src; }
    }

    public void start(Player p, Lrc l, String t, String a) {
        stop();
        player = p; lrc = l; title = t; artist = a; err = "";
        smoothT = 0; cur = 0; pct = 0; seeking = false; paused = false; holdUntil = 0; lastPos = -1;
        lastWall = System.currentTimeMillis();
        long du = 0;
        try { du = p.getDuration(); } catch (Throwable e) {}
        durMs = du > 0 ? (int) (du / 1000) : (l != null ? l.dur : 0);
        try { p.addPlayerListener(this); } catch (Throwable e) { err = "listener loi: " + e; }
        try {
            VolumeControl vc = (VolumeControl) p.getControl("VolumeControl");
            if (vc != null) { vc.setMute(false); vc.setLevel(100); }
        } catch (Throwable e) { err = "volume loi: " + e; }
        try { p.start(); } catch (Throwable e) { err = "START LOI: " + e; }
        running = true;
        new Thread(this).start();
    }

    public void stop() {
        running = false;
        if (player != null) {
            try { player.stop(); } catch (Exception e) {}
            try { player.deallocate(); } catch (Exception e) {}
            try { player.close(); } catch (Exception e) {}
            player = null;
        }
    }

    // ===== updateByTime(t) =====
    private void updateByTime(int t) {
        long now = System.currentTimeMillis();
        if (seeking || now < holdUntil) return;
        if (lrc == null || lrc.n == 0) return;
        cur = lrc.find(t);
        pct = lrc.pct(cur, t);
    }

    // ===== smoothLoop ~60fps =====
    public void run() {
        while (running) {
            long t0 = System.currentTimeMillis();
            try {
                Player p = player;
                if (p != null) {
                    long now = t0;
                    int dt = (int) (now - lastWall); lastWall = now;
                    if (dt < 0 || dt > 200) dt = FRAME_MS;
                    if (durMs <= 0 && now - lastDurChk > 1000) {       // stream: do dai bai co the den tre
                        lastDurChk = now;
                        try { long du = p.getDuration(); if (du > 0) durMs = (int) (du / 1000); } catch (Throwable e) {}
                    }
                    long us = p.getMediaTime();
                    int pos = us >= 0 ? (int) (us / 1000) : smoothT;
                    boolean playing = p.getState() == Player.STARTED;

                    if (seeking) {
                        if (now >= animStart) {
                            long q = (now - animStart) * 1000 / animDur;
                            pct = (int) (q > 1000 ? 1000 : q);
                        }
                        if (now >= seekEnd) seeking = false;
                    } else if (now - seekedAt < 100) {
                        smoothT = pos; lastPos = pos; updateByTime(pos);
                    } else if (playing) {
                        smoothT += dt;
                        if (pos != lastPos) {
                            lastPos = pos;
                            int e = pos - smoothT;
                            if (e > 500 || e < -500) smoothT = pos; else smoothT += e / 4;
                        }
                        updateByTime(smoothT);
                    } else {
                        smoothT = pos; lastPos = pos; updateByTime(pos);
                    }
                    repaint();
                }
            } catch (Throwable e) { err = "RUN LOI: " + e; try { Thread.sleep(300); } catch (Exception x) {} }
            long used = System.currentTimeMillis() - t0;
            long wait = FRAME_MS - used;
            try { Thread.sleep(wait > 1 ? wait : 1); } catch (Exception e) {}
        }
    }

    // ===== 'seeked' =====
    private void onSeeked(int pos) {
        int idx = lrc.find(pos);
        if (idx > 0 && (pos - lrc.time[idx]) < 250) idx--;
        int remain = lrc.end(idx) - pos; if (remain < 200) remain = 200;
        cur = idx; pct = 0;
        smoothT = pos; seekedAt = System.currentTimeMillis();
        if (idx == 0) { seeking = false; holdUntil = 0; updateByTime(pos + 1); }
        else {
            long now = seekedAt;
            holdUntil = now + 300;
            animStart = now + 180; animDur = remain;
            seekEnd = now + (remain > 100 ? remain : 100);
            seeking = true;
        }
        repaint();
    }

    public void playerUpdate(Player p, String ev, Object data) {
        if (PlayerListener.END_OF_MEDIA.equals(ev)) {
            if (repeat && player != null) {
                try {
                    p.setMediaTime(0); p.start();
                    smoothT = 0; lastPos = -1; cur = 0; pct = 0; seeking = false; holdUntil = 0; seekedAt = 0;
                } catch (Exception e) { app.songEnded(); }
            } else app.songEnded();
        } else if (PlayerListener.ERROR.equals(ev)) {
            app.songEnded();
        }
    }

    // ===================== VE =====================
    protected void paint(Graphics g) {
        int w = getWidth(), h = getHeight();
        g.setClip(0, 0, w, h);
        g.setColor(0x303030); g.fillRect(0, 0, w, h);

        // thanh tieu de
        grad(g, 0, 32, w);
        g.setFont(fBig); g.setColor(0xFFFFFF);
        g.drawString("Nghe nhac", w / 2, 16 - fBig.getHeight() / 2, Graphics.TOP | Graphics.HCENTER);

        // hang icon (repeat: phim 1)
        g.setColor(0x3A3A3A); g.fillRect(0, 32, w, 30);
        Image r = repeat ? imRepOn : imRep;
        if (r != null) g.drawImage(r, 8, 40, TL);

        // anh bia + ten bai + ca si
        if (imAlbum != null) g.drawImage(imAlbum, 5, 64, TL);
        g.setFont(fBig); g.setColor(0xFFFFFF);
        g.drawString(clip(title, fBig, w - 83), 79, 68, TL);
        g.setFont(fSmall); g.setColor(0xB57FE0);
        g.drawString(clip(artist, fSmall, w - 83), 79, 68 + fBig.getHeight() + 8, TL);

        // *** 3 dong karaoke: dung cho "Dang tai nhac..." ***
        paintLyrics(g, w, 126, h - 128);

        // thoi gian
        int pos = smoothT; if (pos < 0) pos = 0;
        if (durMs > 0 && pos > durMs) pos = durMs;
        int ty = h - 119 - fSmall.getHeight() / 2;
        g.setFont(fSmall); g.setColor(0xFFFFFF);
        g.drawString(mmss(pos), 6, ty, TL);
        g.drawString(durMs > 0 ? mmss(durMs) : "--:--", w - 6, ty, Graphics.TOP | Graphics.RIGHT);

        // thanh tua
        int bx = 3, bw = w - 6, by = h - 101;
        paintBar(g, bx, by, bw);
        if (imKnob != null) {
            int kr = bw - 8 - imKnob.getWidth();
            int kx = bx + 4 + (durMs > 0 ? (int) ((long) kr * pos / durMs) : 0);
            g.drawImage(imKnob, kx, by + 2, TL);
        }

        // hang nut
        int bby = h - 78;
        g.setColor(0x262626); g.fillRect(0, bby, w, 34);
        int sx = (w - 196) / 2;
        long now = System.currentTimeMillis();
        for (int i = 1; i <= 3; i++) {
            int cx = sx + i * 40;
            g.setColor(flashCell == i && now < flashUntil ? 0x777777 : 0x3C3C3C);
            g.fillRect(cx, bby, 36, 34);
            Image im = (i == 1) ? imPrev : (i == 3 ? imNext : (paused ? imPlay : imPause));
            if (im != null) g.drawImage(im, cx + (36 - im.getWidth()) / 2, bby + (34 - im.getHeight()) / 2, TL);
        }

        // thanh phim mem: trai = dung/phat, phai = quay lai
        grad(g, h - 34, 34, w);
        g.setFont(fBig); g.setColor(0xFFFFFF);
        int sy = h - 34 + (34 - fBig.getHeight()) / 2;
        g.drawString(paused ? "Phat" : "Dung", 6, sy, TL);
        g.drawString("Tro ve", w - 6, sy, Graphics.TOP | Graphics.RIGHT);
    }

    private void paintLyrics(Graphics g, int w, int zt, int zb) {
        int zh = zb - zt;
        if (err.length() > 0) {
            g.setFont(fSmall); g.setColor(0xFF4444);
            g.drawString(clip(err, fSmall, w - 6), 3, zb - fSmall.getHeight(), TL);
        }
        if (lrc == null || lrc.n == 0) {
            g.setFont(fSmall); g.setColor(0xAAAAAA);
            g.drawString("Khong co loi", w / 2, zt + zh / 2 - fSmall.getHeight() / 2, Graphics.TOP | Graphics.HCENTER);
            return;
        }
        Font F = (3 * fBig.getHeight() + 4 <= zh) ? fBig : fSmall;   // vung hep thi dung font nho
        int fh = F.getHeight();
        int gap = (zh - 3 * fh) / 4; if (gap < 0) gap = 0; if (gap > 5) gap = 5;
        int y0 = zt + (zh - 3 * fh - 2 * gap) / 2; if (y0 < zt) y0 = zt;
        int yt = y0, yc = y0 + fh + gap, yb = yc + fh + gap;

        if (cur == 0) {
            fillLine(g, F, lrc.at(0), w, yt, pct, 0xFFFFFF);
            plain(g, F, lrc.at(1), w, yc, 0xFFFFFF);
            plain(g, F, lrc.at(2), w, yb, 0xFFFFFF);
        } else {
            plain(g, fSmall, lrc.at(cur - 1), w, yt + (fh - fSmall.getHeight()) / 2, 0x737373);
            fillLine(g, F, lrc.at(cur), w, yc, pct, 0xFFFFFF);
            plain(g, F, lrc.at(cur + 1), w, yb, 0xFFFFFF);
        }
    }

    private void plain(Graphics g, Font f, String s, int w, int y, int color) {
        g.setFont(f); g.setColor(color);
        int tw = f.stringWidth(s);
        g.drawString(s, tw <= w - 6 ? (w - tw) / 2 : 3, y, TL);
    }

    /** chu nen + phan da hat to mau accent #ff284d (width = pct/1000) */
    private void fillLine(Graphics g, Font f, String s, int w, int y, int p, int base) {
        g.setFont(f);
        int tw = f.stringWidth(s), fw = tw * p / 1000, x;
        if (tw <= w - 8) x = (w - tw) / 2;
        else { x = w / 2 - fw; if (x > 4) x = 4; if (x < w - tw - 4) x = w - tw - 4; }
        g.setColor(base); g.drawString(s, x, y, TL);
        g.setClip(x, y, fw, f.getHeight());
        g.setColor(0xFF284D); g.drawString(s, x, y, TL);
        g.setClip(0, 0, getWidth(), getHeight());
    }

    /** thanh tua gian theo chieu rong: 2 dau 10px + phan giua lap lai */
    private void paintBar(Graphics g, int bx, int by, int bw) {
        if (imBar == null) return;
        int iw = imBar.getWidth(), ih = imBar.getHeight();
        int x = bx + 10, end = bx + bw - 10;
        while (x < end) {
            int cw = iw - 20; if (cw > end - x) cw = end - x;
            g.setClip(x, by, cw, ih); g.drawImage(imBar, x - 10, by, TL);
            x += cw;
        }
        g.setClip(bx, by, 10, ih); g.drawImage(imBar, bx, by, TL);
        g.setClip(bx + bw - 10, by, 10, ih); g.drawImage(imBar, bx + bw - iw, by, TL);
        g.setClip(0, 0, getWidth(), getHeight());
    }

    /** nen tim gradient cho thanh tren / thanh phim mem */
    private void grad(Graphics g, int y, int h, int w) {
        int d = h > 1 ? h - 1 : 1;
        for (int i = 0; i < h; i++) {
            int q = i * 100 / d;
            int c = (q < 30) ? mix(0x35233F, 0x9A58AA, q * 100 / 30) : mix(0x9A58AA, 0x240A2C, (q - 30) * 100 / 70);
            g.setColor(c);
            g.drawLine(0, y + i, w, y + i);
        }
    }

    private static int mix(int a, int b, int p) {
        int r = (((a >> 16) & 255) * (100 - p) + ((b >> 16) & 255) * p) / 100;
        int gg = (((a >> 8) & 255) * (100 - p) + ((b >> 8) & 255) * p) / 100;
        int bl = ((a & 255) * (100 - p) + (b & 255) * p) / 100;
        return (r << 16) | (gg << 8) | bl;
    }

    private static String mmss(int ms) {
        int s = ms / 1000;
        int m = s / 60; s = s % 60;
        StringBuffer o = new StringBuffer();
        if (m < 10) o.append('0');
        o.append(m).append(':');
        if (s < 10) o.append('0');
        o.append(s);
        return o.toString();
    }

    private String clip(String s, Font f, int w) {
        while (s.length() > 1 && f.stringWidth(s) > w) s = s.substring(0, s.length() - 1);
        return s;
    }

    // ===== phim =====
    protected void keyPressed(int k) {
        if (k == -6 || k == -21) { toggle(); return; }             // phim mem trai
        if (k == -7 || k == -22) { app.songEnded(); return; }      // phim mem phai = quay lai
        if (k == KEY_NUM1) { repeat = !repeat; repaint(); return; }
        int ga = 0;
        try { ga = getGameAction(k); } catch (Exception e) {}
        if (ga == FIRE || k == KEY_NUM5) toggle();
        else if (ga == LEFT || k == KEY_NUM4) seek(-5000);
        else if (ga == RIGHT || k == KEY_NUM6) seek(5000);
    }

    private void flash(int cell) { flashCell = cell; flashUntil = System.currentTimeMillis() + 150; }

    private void toggle() {
        try {
            if (player == null) return;
            flash(2);
            if (paused) { player.start(); paused = false; }
            else { player.stop(); paused = true; int pos = (int) (player.getMediaTime() / 1000); smoothT = pos; updateByTime(pos); }
            repaint();
        } catch (Exception e) {}
    }

    private void seek(int ms) {
        try {
            if (player == null) return;
            long t = player.getMediaTime() / 1000 + ms;
            if (t < 0) t = 0;
            if (durMs > 0 && t > durMs - 500) t = (durMs - 500 > 0) ? durMs - 500 : 0;
            player.setMediaTime(t * 1000);
            flash(ms < 0 ? 1 : 3);
            if (lrc != null && lrc.n > 0) onSeeked((int) t);
            else { smoothT = (int) t; lastPos = -1; seekedAt = System.currentTimeMillis(); }
            repaint();
        } catch (Exception e) {}
    }
}
