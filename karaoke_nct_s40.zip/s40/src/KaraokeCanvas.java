import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import javax.microedition.media.control.VolumeControl;

/** Karaoke theo test/playz8.php (ban dang chay that: api/song.php include playz8.php). */
public class KaraokeCanvas extends Canvas implements Runnable, PlayerListener {
    private final KaraokeMidlet app;
    private Player player;
    private Lrc lrc;
    private String title = "", artist = "";

    private int smoothT = 0;                 // ms
    private int cur = 0, pct = 0;
    private long seekedAt = 0;
    // lyricHold / lyricSeeking + animation to dan sau khi tua
    private boolean seeking = false;
    private long holdUntil = 0, seekEnd = 0, animStart = 0, animDur = 1;

    private boolean running = false, paused = false;
    private String dbg = "";                 // dong debug o day man hinh

    public KaraokeCanvas(KaraokeMidlet app) { this.app = app; setFullScreenMode(false); }

    public void start(Player p, Lrc l, String t, String a) {
        stop();
        player = p; lrc = l; title = t; artist = a;
        smoothT = 0; cur = 0; pct = 0; seeking = false; paused = false; holdUntil = 0;
        dbg = "start...";
        try { p.addPlayerListener(this); } catch (Throwable e) { dbg = "listener loi: " + e; }
        try {
            VolumeControl vc = (VolumeControl) p.getControl("VolumeControl");
            if (vc != null) { vc.setMute(false); vc.setLevel(100); }
        } catch (Throwable e) { dbg = "volume loi: " + e; }
        try { p.start(); dbg = "start OK"; } catch (Throwable e) { dbg = "START LOI: " + e; }
        running = true;
        new Thread(this).start();
    }

    public void stop() {
        running = false;
        if (player != null) {
            try { player.stop(); } catch (Exception e) {}
            try { player.close(); } catch (Exception e) {}
            player = null;
        }
    }

    // ===== updateByTime(t) =====
    private void updateByTime(int t) {
        long now = System.currentTimeMillis();
        if (seeking || now < holdUntil) return;          // lyricSeeking || lyricHold
        if (lrc == null || lrc.n == 0) return;
        cur = lrc.find(t);
        pct = lrc.pct(cur, t);
    }

    // ===== smoothLoop =====
    public void run() {
        while (running) {
            try {
                Player p = player;
                if (p != null && lrc != null && lrc.n > 0) {
                    long now = System.currentTimeMillis();
                    long us = p.getMediaTime();
                    if (!dbg.startsWith("START LOI")) dbg = "st=" + p.getState() + " t=" + (us / 1000) + "ms n=" + lrc.n + " cur=" + cur;
                    int pos = us >= 0 ? (int) (us / 1000) : smoothT;

                    if (seeking) {                        // fill chay dan 0 -> 100% trong 'remain'
                        if (now >= animStart) {
                            long q = (now - animStart) * 100 / animDur;
                            pct = (int) (q > 100 ? 100 : q);
                        }
                        if (now >= seekEnd) seeking = false;
                    } else if (now - seekedAt < 100) {
                        smoothT = pos; updateByTime(pos);
                    } else if (p.getState() == Player.STARTED) {
                        int d = pos - smoothT; if (d < 0) d = -d;
                        if (d > 400) { smoothT = pos; updateByTime(pos); }
                        else { smoothT = (smoothT * 85 + pos * 15) / 100; updateByTime(smoothT); }
                    } else {
                        smoothT = pos; updateByTime(pos);
                    }
                    repaint();
                }
                Thread.sleep(80);
            } catch (Throwable e) { dbg = "RUN LOI: " + e; try { Thread.sleep(300); } catch (Exception x) {} }
        }
    }

    // ===== 'seeked' =====
    private void onSeeked(int pos) {
        int idx = lrc.find(pos);
        if (idx > 0 && (pos - lrc.time[idx]) < 250) idx--;
        int remain = lrc.end(idx) - pos; if (remain < 200) remain = 200;
        cur = idx; pct = 0;
        smoothT = pos; seekedAt = System.currentTimeMillis();
        if (idx == 0) { seeking = false; holdUntil = 0; updateByTime(pos + 1); }
        else {
            long now = seekedAt;
            holdUntil = now + 300;
            animStart = now + 180; animDur = remain;
            seekEnd = now + (remain > 100 ? remain : 100);
            seeking = true;
        }
        repaint();
    }

    public void playerUpdate(Player p, String ev, Object data) {
        if (PlayerListener.END_OF_MEDIA.equals(ev) || PlayerListener.ERROR.equals(ev)) app.songEnded();
    }

    // ===== ve (renderThreeLines) =====
    protected void paint(Graphics g) {
        int w = getWidth(), h = getHeight();
        g.setColor(0x000000); g.fillRect(0, 0, w, h);
        Font small = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL);
        Font big = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_MEDIUM);

        g.setFont(small);
        g.setColor(0xFFFFFF); g.drawString(clip(title, small, w - 6), 3, 2, Graphics.TOP | Graphics.LEFT);
        g.setColor(0x888888); g.drawString(clip(artist, small, w - 6), 3, 2 + small.getHeight(), Graphics.TOP | Graphics.LEFT);

        g.setFont(small); g.setColor(0xFFFF00);
        g.drawString(clip(dbg, small, w - 6), 3, h - small.getHeight() - 2, Graphics.TOP | Graphics.LEFT);

        if (lrc == null || lrc.n == 0) {
            g.setColor(0xAAAAAA);
            g.drawString("Khong co loi", w / 2, h / 2, Graphics.HCENTER | Graphics.BASELINE);
            return;
        }
        int yc = h / 2 - big.getHeight() / 2;
        int yt = yc - big.getHeight() - 6;
        int yb = yc + big.getHeight() + 6;

        if (cur == 0) {
            // dong dau: hien o o TREN va to mau o do; giua = dong 2, duoi = dong 3
            fillLine(g, big, lrc.at(0), w, yt, pct, 0xFFFFFF);
            plain(g, big, lrc.at(1), w, yc, 0xFFFFFF);
            plain(g, big, lrc.at(2), w, yb, 0xFFFFFF);
        } else {
            plain(g, small, lrc.at(cur - 1), w, yt, 0x737373);     // top: mo, khong to
            fillLine(g, big, lrc.at(cur), w, yc, pct, 0xFFFFFF);   // giua: to theo pct
            plain(g, big, lrc.at(cur + 1), w, yb, 0xFFFFFF);
        }
    }

    private void plain(Graphics g, Font f, String s, int w, int y, int color) {
        g.setFont(f); g.setColor(color);
        int tw = f.stringWidth(s);
        g.drawString(s, tw <= w - 6 ? (w - tw) / 2 : 3, y, Graphics.TOP | Graphics.LEFT);
    }

    /** chu nen + phan da hat to mau accent #ff284d (width = pct%) */
    private void fillLine(Graphics g, Font f, String s, int w, int y, int p, int base) {
        g.setFont(f);
        int tw = f.stringWidth(s), fw = tw * p / 100, x;
        if (tw <= w - 8) x = (w - tw) / 2;
        else { x = w / 2 - fw; if (x > 4) x = 4; if (x < w - tw - 4) x = w - tw - 4; }
        g.setColor(base); g.drawString(s, x, y, Graphics.TOP | Graphics.LEFT);
        g.setClip(x, y, fw, f.getHeight());
        g.setColor(0xFF284D); g.drawString(s, x, y, Graphics.TOP | Graphics.LEFT);
        g.setClip(0, 0, getWidth(), getHeight());
    }

    private String clip(String s, Font f, int w) {
        while (s.length() > 1 && f.stringWidth(s) > w) s = s.substring(0, s.length() - 1);
        return s;
    }

    // ===== phim =====
    protected void keyPressed(int k) {
        int ga = getGameAction(k);
        if (ga == FIRE || k == KEY_NUM5) toggle();
        else if (ga == LEFT || k == KEY_NUM4) seek(-5000);
        else if (ga == RIGHT || k == KEY_NUM6) seek(5000);
    }

    private void toggle() {
        try {
            if (player == null) return;
            if (paused) { player.start(); paused = false; }
            else { player.stop(); paused = true; int pos = (int) (player.getMediaTime() / 1000); smoothT = pos; updateByTime(pos); repaint(); }
        } catch (Exception e) {}
    }

    private void seek(int ms) {
        try {
            if (player == null || lrc == null || lrc.n == 0) return;
            long t = player.getMediaTime() / 1000 + ms;
            if (t < 0) t = 0;
            player.setMediaTime(t * 1000);
            onSeeked((int) t);
        } catch (Exception e) {}
    }
}
