import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import javax.microedition.media.control.VolumeControl;

/** Karaoke theo test/playz8.php (ban dang chay that: api/song.php include playz8.php). */
public class KaraokeCanvas extends Canvas implements Runnable, PlayerListener {
    private final KaraokeMidlet app;
    private Player player;
    private Lrc lrc;
    private String title = "", artist = "";

    private int smoothT = 0;                 // ms
    private int cur = 0, pct = 0;
    private long seekedAt = 0;
    // lyricHold / lyricSeeking + animation to dan sau khi tua
    private boolean seeking = false;
    private long holdUntil = 0, seekEnd = 0, animStart = 0, animDur = 1;

    private boolean running = false, paused = false;
    private String dbg = "";                 // dong debug o day man hinh
    private long lastWall = 0, lastDbg = 0, fpsT = 0;
    private int lastPos = -1, frames = 0, fps = 0;
    private static final int FRAME_MS = 16;  // ~60 fps
    private Font fSmall, fBig;

    public KaraokeCanvas(KaraokeMidlet app) {
        this.app = app; setFullScreenMode(false);
        fSmall = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL);
        fBig = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_MEDIUM);
    }

    public void start(Player p, Lrc l, String t, String a) {
        stop();
        player = p; lrc = l; title = t; artist = a;
        smoothT = 0; cur = 0; pct = 0; seeking = false; paused = false; holdUntil = 0; lastPos = -1; lastWall = System.currentTimeMillis();
        if (p == null) {
            dbg = "KHONG MP3 - chi chay chu";
        } else {
            dbg = "start...";
            try { p.addPlayerListener(this); } catch (Throwable e) { dbg = "listener loi: " + e; }
            try {
                VolumeControl vc = (VolumeControl) p.getControl("VolumeControl");
                if (vc != null) { vc.setMute(false); vc.setLevel(100); }
            } catch (Throwable e) { dbg = "volume loi: " + e; }
            try { p.start(); dbg = "start OK"; } catch (Throwable e) { dbg = "START LOI: " + e; }
        }
        running = true;
        new Thread(this).start();
    }

    public void stop() {
        running = false;
        if (player != null) {
            try { player.stop(); } catch (Exception e) {}
            try { player.close(); } catch (Exception e) {}
            player = null;
        }
    }

    // ===== updateByTime(t) =====
    private void updateByTime(int t) {
        long now = System.currentTimeMillis();
        if (seeking || now < holdUntil) return;          // lyricSeeking || lyricHold
        if (lrc == null || lrc.n == 0) return;
        cur = lrc.find(t);
        pct = lrc.pct(cur, t);
    }

    // ===== smoothLoop: ~60fps, dong ho tu noi suy giua cac lan getMediaTime (Android tra ve thoi gian theo nac) =====
    public void run() {
        while (running) {
            long t0 = System.currentTimeMillis();
            try {
                Player p = player;
                if (p == null && running && lrc != null && lrc.n > 0) {
                    // ===== che do KHONG CO NHAC: chu chay theo dong ho he thong =====
                    long now = t0;
                    int dt = (int) (now - lastWall); lastWall = now;
                    if (dt < 0 || dt > 200) dt = FRAME_MS;
                    if (!paused) smoothT += dt;
                    if (seeking) {
                        if (now >= animStart) {
                            long q = (now - animStart) * 1000 / animDur;
                            pct = (int) (q > 1000 ? 1000 : q);
                        }
                        if (now >= seekEnd) seeking = false;
                    } else if (now - seekedAt >= 100) {
                        updateByTime(smoothT);
                    }
                    frames++;
                    if (now - fpsT >= 1000) { fps = frames; frames = 0; fpsT = now; }
                    if (now - lastDbg >= 250) {
                        lastDbg = now;
                        dbg = "NO MP3 fps=" + fps + " t=" + smoothT + " cur=" + cur + (paused ? " (pause)" : "");
                    }
                    if (smoothT > lrc.time[lrc.n - 1] + 6000) { running = false; app.songEnded(); }
                    repaint();
                } else if (p != null && lrc != null && lrc.n > 0) {
                    long now = t0;
                    int dt = (int) (now - lastWall); lastWall = now;
                    if (dt < 0 || dt > 200) dt = FRAME_MS;
                    long us = p.getMediaTime();
                    int pos = us >= 0 ? (int) (us / 1000) : smoothT;
                    boolean playing = p.getState() == Player.STARTED;

                    if (seeking) {                        // fill chay dan 0 -> 100% trong 'remain'
                        if (now >= animStart) {
                            long q = (now - animStart) * 1000 / animDur;
                            pct = (int) (q > 1000 ? 1000 : q);
                        }
                        if (now >= seekEnd) seeking = false;
                    } else if (now - seekedAt < 100) {
                        smoothT = pos; lastPos = pos; updateByTime(pos);
                    } else if (playing) {
                        smoothT += dt;                                        // tu chay theo dong ho he thong
                        if (pos != lastPos) {                                 // co mau moi tu player -> keo nhe ve cho khop
                            lastPos = pos;
                            int err = pos - smoothT;
                            if (err > 500 || err < -500) smoothT = pos; else smoothT += err / 4;
                        }
                        updateByTime(smoothT);
                    } else {
                        smoothT = pos; lastPos = pos; updateByTime(pos);
                    }

                    frames++;
                    if (now - fpsT >= 1000) { fps = frames; frames = 0; fpsT = now; }
                    if (now - lastDbg >= 250 && !dbg.startsWith("START LOI")) {
                        lastDbg = now;
                        dbg = "fps=" + fps + " st=" + p.getState() + " t=" + (us / 1000) + " cur=" + cur;
                    }
                    repaint();
                }
            } catch (Throwable e) { dbg = "RUN LOI: " + e; try { Thread.sleep(300); } catch (Exception x) {} }
            long used = System.currentTimeMillis() - t0;
            long wait = FRAME_MS - used;
            try { Thread.sleep(wait > 1 ? wait : 1); } catch (Exception e) {}
        }
    }

    // ===== 'seeked' =====
    private void onSeeked(int pos) {
        int idx = lrc.find(pos);
        if (idx > 0 && (pos - lrc.time[idx]) < 250) idx--;
        int remain = lrc.end(idx) - pos; if (remain < 200) remain = 200;
        cur = idx; pct = 0;
        smoothT = pos; seekedAt = System.currentTimeMillis();
        if (idx == 0) { seeking = false; holdUntil = 0; updateByTime(pos + 1); }
        else {
            long now = seekedAt;
            holdUntil = now + 300;
            animStart = now + 180; animDur = remain;
            seekEnd = now + (remain > 100 ? remain : 100);
            seeking = true;
        }
        repaint();
    }

    public void playerUpdate(Player p, String ev, Object data) {
        if (PlayerListener.END_OF_MEDIA.equals(ev) || PlayerListener.ERROR.equals(ev)) app.songEnded();
    }

    // ===== ve (renderThreeLines) =====
    protected void paint(Graphics g) {
        int w = getWidth(), h = getHeight();
        g.setColor(0x000000); g.fillRect(0, 0, w, h);
        Font small = fSmall, big = fBig;

        g.setFont(small);
        g.setColor(0xFFFFFF); g.drawString(clip(title, small, w - 6), 3, 2, Graphics.TOP | Graphics.LEFT);
        g.setColor(0x888888); g.drawString(clip(artist, small, w - 6), 3, 2 + small.getHeight(), Graphics.TOP | Graphics.LEFT);

        g.setFont(small); g.setColor(0xFFFF00);
        g.drawString(clip(dbg, small, w - 6), 3, h - small.getHeight() - 2, Graphics.TOP | Graphics.LEFT);

        if (lrc == null || lrc.n == 0) {
            g.setColor(0xAAAAAA);
            g.drawString("Khong co loi", w / 2, h / 2, Graphics.HCENTER | Graphics.BASELINE);
            return;
        }
        int yc = h / 2 - big.getHeight() / 2;
        int yt = yc - big.getHeight() - 6;
        int yb = yc + big.getHeight() + 6;

        if (cur == 0) {
            // dong dau: hien o o TREN va to mau o do; giua = dong 2, duoi = dong 3
            fillLine(g, big, lrc.at(0), w, yt, pct, 0xFFFFFF);
            plain(g, big, lrc.at(1), w, yc, 0xFFFFFF);
            plain(g, big, lrc.at(2), w, yb, 0xFFFFFF);
        } else {
            plain(g, small, lrc.at(cur - 1), w, yt, 0x737373);     // top: mo, khong to
            fillLine(g, big, lrc.at(cur), w, yc, pct, 0xFFFFFF);   // giua: to theo pct
            plain(g, big, lrc.at(cur + 1), w, yb, 0xFFFFFF);
        }
    }

    private void plain(Graphics g, Font f, String s, int w, int y, int color) {
        g.setFont(f); g.setColor(color);
        int tw = f.stringWidth(s);
        g.drawString(s, tw <= w - 6 ? (w - tw) / 2 : 3, y, Graphics.TOP | Graphics.LEFT);
    }

    /** chu nen + phan da hat to mau accent #ff284d (width = pct/1000) */
    private void fillLine(Graphics g, Font f, String s, int w, int y, int p, int base) {
        g.setFont(f);
        int tw = f.stringWidth(s), fw = tw * p / 1000, x;
        if (tw <= w - 8) x = (w - tw) / 2;
        else { x = w / 2 - fw; if (x > 4) x = 4; if (x < w - tw - 4) x = w - tw - 4; }
        g.setColor(base); g.drawString(s, x, y, Graphics.TOP | Graphics.LEFT);
        g.setClip(x, y, fw, f.getHeight());
        g.setColor(0xFF284D); g.drawString(s, x, y, Graphics.TOP | Graphics.LEFT);
        g.setClip(0, 0, getWidth(), getHeight());
    }

    private String clip(String s, Font f, int w) {
        while (s.length() > 1 && f.stringWidth(s) > w) s = s.substring(0, s.length() - 1);
        return s;
    }

    // ===== phim =====
    protected void keyPressed(int k) {
        int ga = getGameAction(k);
        if (ga == FIRE || k == KEY_NUM5) toggle();
        else if (ga == LEFT || k == KEY_NUM4) seek(-5000);
        else if (ga == RIGHT || k == KEY_NUM6) seek(5000);
    }

    private void toggle() {
        try {
            if (player == null) { paused = !paused; return; }
            if (paused) { player.start(); paused = false; }
            else { player.stop(); paused = true; int pos = (int) (player.getMediaTime() / 1000); smoothT = pos; updateByTime(pos); repaint(); }
        } catch (Exception e) {}
    }

    private void seek(int ms) {
        try {
            if (lrc == null || lrc.n == 0) return;
            if (player == null) {                       // khong co nhac: tua dong ho
                int t2 = smoothT + ms; if (t2 < 0) t2 = 0;
                onSeeked(t2);
                return;
            }
            long t = player.getMediaTime() / 1000 + ms;
            if (t < 0) t = 0;
            player.setMediaTime(t * 1000);
            onSeeked((int) t);
        } catch (Exception e) {}
    }
}
