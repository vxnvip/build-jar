import java.util.Vector;
import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import javax.microedition.media.control.VolumeControl;

/** Giao dien ZingMp3 (240x320) + 3 dong karaoke dat vao cho "Dang tai nhac...". */
public class KaraokeCanvas extends Canvas implements Runnable, PlayerListener {
    private static final int TL = Graphics.TOP | Graphics.LEFT;

    private final KaraokeMidlet app;
    private Player player;
    private Lrc lrc;
    private String title = "", artist = "";
    private int durMs = 0;
    private boolean repeat = false;
    private int flashCell = -1;
    private long flashUntil = 0;

    private int smoothT = 0;                 // ms
    private int cur = 0, pct = 0;
    // ----- hieu ung luot len khi sang cau moi (giong renderThreeLines tren web) -----
    private static final int SLIDE_MS = 280;
    private static final boolean SHOW_SUNG_LINE = true;   // true: giu dong vua hat xong (xam) o hang tren; false: an di
    private static final int DD = 52;       // duong kinh dia (px) ~ .disc-wrap 108/130 cua .turntable
    private int discAng100 = 0;             // goc quay dia, don vi 0.01 do (0..35999)
    private int[] albumRgb, rotBuf;          // anh bia da cat tron / khung hinh dang quay
    private int rotStep = -1;
    private int[] armBuf = new int[62 * 62];  // lop ve kim (ARGB, khu rang cua)
    private int armPos = 0;                  // vi tri chan kim 0 (nhac len) .. 1000 (dat vao dia)
    private int lastC = 1;                   // dong o hang giua lan ve truoc (cur<1 thi coi la 1)
    private boolean shown = false;           // false = chua toi gio hien loi / hat het bai roi
    private long slideStart = 0;             // 0 = khong dang luot
    private long seekedAt = 0;
    private boolean seeking = false;
    private long holdUntil = 0, seekEnd = 0, animStart = 0, animDur = 1;

    private boolean running = false, paused = false, playingNow = false;
    private String dbg = "";
    private long lastDbg = 0;
    private String err = "";
    private long lastWall = 0, lastDurChk = 0;
    private int lastPos = -1;
    private static final int FRAME_MS = 16;  // ~60 fps
    private Font fSmall, fBig, fMenu;

    // ----- menu / man hinh loi (giong ZingMp3) -----
    private static final int M_PLAYER = 0, M_MENU = 1, M_LYRICS = 2;
    private static final String T_TITLE = "Nghe nh\u1EA1c", T_BACK = "Tr\u1EDF v\u1EC1", T_DONG = "\u0110\u00F3ng",
        T_CHON = "Ch\u1ECDn", T_LYRIC = "L\u1EDDi h\u00E1t", T_NOLYRIC = "Ch\u01B0a c\u00F3 l\u1EDDi",
        T_NOSUPPORT = "Ch\u01B0a h\u1ED7 tr\u1EE3";
    private static final String[] MENU = { "Trang ch\u1EE7", "T\u00F9y ch\u1EC9nh", "M\u1EDF playlist", "L\u1EDDi h\u00E1t", "C\u00F9ng ca s\u0129" };
    private int mode = M_PLAYER, menuSel = 0, lyScroll = 0, lyWrapW = -1;
    private String lyText = "";
    private String[] lyWrap = null;
    private String toast = "";
    private long toastUntil = 0;

    private Image imAlbum, imPrev, imPlay, imPause, imNext, imBar, imKnob, imRep, imRepOn;

    public KaraokeCanvas(KaraokeMidlet app) {
        this.app = app;
        setFullScreenMode(true);
        fSmall = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL);
        fBig = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_MEDIUM);
        fMenu = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_MEDIUM);
        imAlbum = scale(load("/defaultAlbum.png"), 60, 60);
        initDisc();
        imRep = scale(load("/repeat.png"), 14, 14);
        imRepOn = scale(load("/repeat_over.png"), 14, 14);
        imPrev = load("/btn_prev.png");
        imPlay = load("/btn_play.png");
        imPause = load("/btn_pause.png");
        imNext = load("/btn_next.png");
        imBar = load("/bgd_slide.png");
        imKnob = load("/slider.png");
    }

    private static Image load(String p) {
        try { return Image.createImage(p); } catch (Throwable e) {}       // 1) doc tu jar neu co
        try {                                                               // 2) khong co -> dung ban nhung san
            String h = hex(p);
            if (h == null) return null;
            int n = h.length() / 2;
            byte[] b = new byte[n];
            for (int i = 0; i < n; i++) b[i] = (byte) ((hv(h.charAt(2 * i)) << 4) | hv(h.charAt(2 * i + 1)));
            return Image.createImage(b, 0, n);
        } catch (Throwable e) { return null; }
    }

    /** anh giao dien nhung san trong code (hex PNG) -> khong phu thuoc viec dong goi res/ vao jar */
    private static String hex(String p) {
        if (p.equals("/defaultAlbum.png")) return "89504e470d0a1a0a0000000d4948445200000064000000640803000000473c65660000001974455874536f6674776172650041646f626520496d616765526561647971c9653c00000060504c54458484849191912d2d2d8181813535352828282424248888881e1e1e7878784343438e8e8e0b0b0b1111117272728c8c8c7070707474747b7b7b6b6b6b6969697e7e7e7d7d7d6666667a7a7a6f6f6f2b2b2b191919ffffff5353535b5b5b98989846674bfa000003154944415478daecda0dcfaa201806605e03425f45b45386a4fdff7f7940fcca141f2d3d3b9bf7d61a35b942ca7898e8a113ffc4f3f91d06704cfc34dd3f907e3cef90a4c3808ebad50882f67feb072c55480c1174afd7611a695e410ffd946f974a41f11ec8697be459cdba772007722007f28f104219a3946c8a101a8561a8e8b608c3fabfdd273b20f77c0704ed81fce23d90620f446e8d9865e119ef80c425d914f1ce26c823db23e7127c69f9003963a8d222e972e4940395f403e4cc8117e38f9073c6408a457c5d1bac41808aa92c9e4826e96d0182ba9410e596defd1f24254fd72120e59672a911c1395d8740149f8b1a518cae42d0dcbc10c63b442946d620eeb110aa548d709e28056334721a64fa026308a512cefb08806991b4538a71c5120d223a44cdcd4d8b64c5b541ae639731c29a1e352206888e6b2635624bf82c0fd2a69c4f08795b0176dd8d23663893a799e50d9263bf515efec25e843ee2ab61269c3ed229373c25e8f8d3c804a411bbb162901cdfeb6d96c202ef420f49c6110bbd481ab1db36159207f5cecec5acc3277af013837017622543911144cf7e15d7f11ae110a4c3982276e3a764acfaec856dd2ef213a11f5ab94cd0bb26a7adb22780b840d100543c4474894cd23aedfc9389254e990c2348903e15f40b0693200927c88648e23923508afd2219e6e155f42a2c814d7babc1e2254b7f02c22e791aa7ff383d71943a81b9110240c235c8897141d2244a9e611bb5a710d2390c3f410295d674bbd2c89a6c71195d28178d2391018128623460f092e04824837822f23e9beb405563388ac10c15d3392b9116fe69ba907328fd08b1b514044f2a5676b09226b446c88080012057fc6829723d281e031236360440210e58d2181fa2ea2b291b02f2351f16ec067043a12f26614eaeb88c203a3641b202a781dc722038c28afec8c6099014714c376fa4bbc905882d85a92aa155986accc811cc8811cc8ff8bf03d10b43df244718b3046d9aa4cef7659e4811e5c3a2284ad447955befb5daa76fd9e10ae2e2432b75e49775aa7b5dade0182ae19ec4d64be9c75fa501f9813a43cd577aa6d7e3bdc5f010600870ea528efee51fc0000000049454e44ae426082";
        if (p.equals("/repeat.png")) return "89504e470d0a1a0a0000000d49484452000000280000002808060000008cfeb86d000000097048597300000b1300000b1301009a9c18000000206348524d00007a25000080830000f9ff000080e9000075300000ea6000003a980000176f925fc5460000017e4944415478daec98b14a03411445cf2621602182601b112cfc82b482904a101445d1c660676921d662e11f8860ab28d80882ad22087e432a6dac04053118946b330bdb243bcbcc2653cc85c76ef178739879776676134984ac0a812b0246c0081820e01150b54d4e46b00f7e000fc006d00d758997807b60ca07e0187006bc01f21013a66e13780266078e2e292fce55aede2535fb8d6fd383df6616cbd435b0e6b2c465ea02d80a751f3c31703d5f805d600e481c22d521b09b3ba28549b27ab1c8b7a9b767deeb924e07e58f0270c73c1b929e4d5d5c5c9c4d7805a63df45e0bb80426d313ad5f626d04c6a80377b6e7711193fc01fb1e007b452e0b9502706de00a581fea7c5b9a64dbbc2f4bfaf5e4e4ac9c5c9cba6e51d24f5e418b982902687b1f6c01b7a6c1cb50e2d283f3c04d8970ce37ea4eee9dcd4d5fc0b8cb0cae009f25df669c5c8ca4858c417ca923e94052d5d5c5696c9ac28f1eb619eba8155c8a06b03a4c93143d8b8f4beec720be8be3af8f081801236048fa1f00d8a2d43fea6b25270000000049454e44ae426082";
        if (p.equals("/repeat_over.png")) return "89504e470d0a1a0a0000000d49484452000000280000002808060000008cfeb86d000000097048597300000b1300000b1301009a9c18000000206348524d00007a25000080830000f9ff000080e9000075300000ea6000003a980000176f925fc5460000048e4944415478daec985f8854551cc73fbf73ffcccceabaae255ad92e1144413d4861f9508b840f62044a7fa0a7042188dea25e85e8a1e8b1870812825094202802df322d2a7c28c81e2a1649612b5d5767ffceccbdf7fc7e3d9c3bebae9a77da1191d8c39c19e69ecbf0b9dfdff9fdbebf336266dccec3719b8f55c055c055c08a11f7fb03c747cf2ebf2020123e11ba6f808597f236c601c003ec383b7a6b1514019c20b1e05221aa87e9d2704d22794d1c9f018d5ba260d490ab1e5990185c224802124950ae303437b40396f12cd8d7663c034cdef081ab9ce4bbed130d81f71176039b2b158c4012c1d5ca99802968c7f0f3865f50fc9ca11dc3bc8d9bb16bc71fa3e32b06fc71efdf8770bc24d26388a312ac7e05d214fcbc524c2bf965256f7afcec22e4255376ed383b7a6a45211eb83fd923d192bd5e0558ee3d572f672a5861f83923bbe891d4636658a1981a666cc07803787e4580838fa48d00283d2a5886380de19558d0ccc89b8aa465b817145d30b42348ce61c3f6ad38491aa3f1b24a515d594bb0a49bb561ff75418b19251a70b89a22897c3076fade57fbcae264380aa150c0d33263ebfa6db5dfbaebcd539de50a3aae64712c8b85cca594aa8a490244bc2570a06f27912884c532c3b76d72291c80b674d9f42d43db866f19bea5683b7cd70c2c37ac002b781de580417ae281731ff6a56031a71433a13c68e7da18b727fcf5f76012149354b0dc28a6956256f16ddbafb91db48211cc3ec5d806bcb262c0f684279bf4144dc5cf2bbcb07c7df674e7da2cae95ee3120c46b43907cdbbaf5efa0e5ec34b323281bfa7692ecbca7fd67112067f59af585f1fcfa806b8478d0910c47a1167a433303b514380644bd94ae6ac0294fe7bc27bbe07d31ad6ff612625717a2358e64d83083649d0b59ed4062c924269248c0496569a84c92625a299aeaf3cb7edfe3c7ef3e7af2a1732f2e5dcf2ff965339b52f2a9e016c58ca2ad002909b84650366a94cd430f0650a9a06f1bdad6fd4f9cb8e793930f9edba31d3b041c5d5c6fd95565c6c004491d56744b8c100d389050115cc3e152bd398022ec7ff48bbb3efe616c62b71b70477016ddb09b11aed85c5d16558bd786fb2c93fb5c2da82722950625bd9c8b7f7ef9c2cebca95ffa394d83c15714d79a100f396a9b221aa331f52d31f190c33ce4539ef9f19cd6999cf644d8164ffd3a222b56f0ccbbcdb17453f4793420a99f77dd0ea412301a74d4364624774624eb1daee1d02c589efc8736b91230dd1c7d14ad95866f19da0aa5c28a0ac0b49bc58e7463443ce482eda9853d67cbbc7dae2fc0c69678af16f68d6536a459e88cab422c71a9e21a473c28b8ba0b2d574b40c17c3901330ef70578c7d38dd3333f75f65ac1312d2cb582a0442f1d4d2a443501019f053fd74e1905cf38de0e62bcd7f79964ddd6da57b3bf64fb24e79079be1d7aacfee4bf75338b07a7287436e641732b3dbdf4e356d94d1730f6fbc8cd39340d3e9c1ebefc7d7bc40a9ebbba9bb97e9cbb3780ef184553e94c7ab28b9e625af16d450beb3f49968ee1edf577fe3a3a377d23ab5b3a4cc37ed5566854b38b9eec7c00d485ea64ebb90eaefef5b10ab80ab80af83f06fc670055657eb174537df30000000049454e44ae426082";
        if (p.equals("/btn_prev.png")) return "89504e470d0a1a0a0000000d494844520000001e00000019080600000026359e1a0000001974455874536f6674776172650041646f626520496d616765526561647971c9653c0000016f4944415478da62fcffff3fc340002686010223cf62163c722a40cc8f26f617882f9060be19109fc22a034a5cd8f0dfbf7fb700f17f34fc01977a34bdd240bc11880fe3528333a8fffdfb871513027ffefc4906aabb0ac47ef8d4e30c6aa06bb16b60c1aee5e7cf9f8a406a2610bb12a39e058fcbb18ab3b3b363887dfdfa351f48b500310f31eac9f23132f8f4e9933a909a03c436544bd5401f7fc1220cf6d1bb77ef9881542910d701312755b313d0626c5e667ef5ea952e905e04c40634c9c7b8e21808ce00311bcd0a103c16db42e35597264526c8626c584e4eee14903604e24a20fe8e4b1d0c53d3c70c4a4a4aa0f8efb875ebd61a203d0d3def52e4635076c28691819a9ada1d2076038ac701f13b42ea290a6a6c4053537331504e158817131bd414f91819e8eaeabe036290cf412170876c1f935b49181818ec06aad303e20e20c6693323ae36d79933679ca075323a58606262f28b980404344314a8f63549168fb6b9868dc50001060022fb8d22abc6c8840000000049454e44ae426082";
        if (p.equals("/btn_play.png")) return "89504e470d0a1a0a0000000d494844520000001e00000019080600000026359e1a0000001974455874536f6674776172650041646f626520496d616765526561647971c9653c0000014e4944415478da62fcffff3fc3400026860102c4586c03c4d274b718181536407c158873e86af1bf7fff40981f8827fffdfbf718106bd1d36218b604e2f3bf7fff6e01624e7a5a0cc26c405c0d72c0cf9f3f9d686631306871617520defbeddbb7f940cc4f4f8b613801886f7ffefc398ad6418d0d8b02f1d28f1f3f6e0762457af918197b00f1d577efde950231333d2d06614e20ee02e233af5fbf36c0652e0b3116930940969e79f1e2c544205d232121f19d248bfffcf94349767d07c4c7656464bed3d3c7cb8038575e5efe1dbd82fa2910a72b29296dc5a788da16cf02e2325555d58f8414b210938f8900f78138455d5d7d1fb12ea4868ffb80b85e4b4beb0b29414389c5378138515757f73839298f9ca006b9a403885bf5f5f5bf939be449b5f83210c7191a1a5ea05743e01710d700b109352c25cac7c0b616c897264070999a6d2ec6816a5703041800440668b2d190b66f0000000049454e44ae426082";
        if (p.equals("/btn_pause.png")) return "89504e470d0a1a0a0000000d494844520000001e00000019080600000026359e1a0000001974455874536f6674776172650041646f626520496d616765526561647971c9653c0000009c4944415478da62fcffff3fc34000268601020366310b116a428058084d6c07103f02623920f64093fb02c4cb089a0a8a637cf8efdfbf9780f83f1af686ca7963917b48c84c1026e8e37ffffe618f232626bc72140735d007d835b2b0e095a399c584e486aec57ffefc214b6ed4c7a3168fc6f16801327016e3aa8108c951c3e23540ea389af023a81c889e8526f78e188b19471b7bc3de6280000300f5c9d1a12679d9390000000049454e44ae426082";
        if (p.equals("/btn_next.png")) return "89504e470d0a1a0a0000000d494844520000001e00000019080600000026359e1a0000001974455874536f6674776172650041646f626520496d616765526561647971c9653c000001534944415478da62fcffff3fc340002686010223cf62163c728a40fc1d885f1069961910fb01b1289a7813103fc5500d4a5cd8f0dfbf7fbd81f8031067e25283a6be1d88ff63c1bad8d4e30cea7ffffe81303f104ffbf3e7cf6120d6c2e75da87aac98a43806ba1419db00f1f99f3f7f3602311b11ea51304916037d888ed980b80e882f7dfdfad58608f5704c52e2c2e552205007e2c39f3e7d9a0ba48bf9f8f83e42d5ffa54a76c2e703284e06e21befdebd0b87aaff42151fe3d28006248078c5ab57af6281f423aae463222d86016fac7995c616832ccc026250766ba797c5e004a6a4a4f4f1debd7b5af4f0f17d204e575353db4d66d490959dfa80b85e5353f30b91ea29f6f14d204ed4d5d53d4e85c448948f418c0e206e353030f84e4608916631b470bf0cc4714646461708190454ff85148b1971b5b9ce9c392304a4be989898fca245438071b4b137ec2d060830002d347a7fab8ebf3c0000000049454e44ae426082";
        if (p.equals("/bgd_slide.png")) return "89504e470d0a1a0a0000000d49484452000000da00000015080600000020a3f0ba000000097048597300000b1300000b1301009a9c18000000206348524d00007a25000080830000f9ff000080e9000075300000ea6000003a980000176f925fc546000002c84944415478daecda3f6b535118c7f1df39cfb90d3726f7e616d39aa4488b5162c18a83a0ddebd82593681c44101c5cfb067c032e226ee58a7472f20db8b97611fa27151a68116dd2346d49ef9f731cb421b135a6356ecf674da607be3ce7dc7b853106a7f17ddf029005636c50f542a1d0f6463d388e8344228189c20400409d12d8b5838383777b7b7bb7b4d66d9e1d6383114224f6f7f73fa752a9cae4d4e4f25876acf35b4f688b8b8bafb6b6b61e3aae939e9c9ac4c8c848524a0921044f91b13f30c6406b8d2008b0f37de746ad56fb18c7f17b227a7c2234dff75fd41bf5fb333767d2a3de28d24e1a966571648c0d185b188668b55a68341aeedaea5ab9ba5efd367b7776a127b420081e4d4f4f6772b91c5cd785528a2363ec8cb1a5d369a4522924120967a3baf114c00200c85fdbec8a31c6cbe7f31c1963e7bfa3c1b22c388e83f1f17110117cdfbfdd090dc065dbb623dbb641441c1963ff808860db3692c9240014ba432322e23b19634320a584a52c28a50400ea0e0d420808080e8db1a19c23d1d392e48930f6ffa97e3fd6366b088280a7c4d8001cd741369b3d7b6847474768b7f9e310c6066127edf36db4e2d5224f8fb121e87918027e0ec2d850fcfe50f138b45808c1efd0181b52644404223200e2eea3e3661cc78a8800fcfc94843176fed0841008c31000be74365aa552a95a96b5130621945220493c2dc6ce731793124a29186d2084882a95ca72f746c3e1e1e183ededed0fa5eba50c2c208a2268ad6160005e708cf559618080809412a4085248d4366bcd76bbfdbaf397ee63e2d2d2d2cb62b1f8a4542a258fef6b7c8c646cb0e3a281411cc7a8ae575b2b2b2b6fe7eecd3df332dec9d000c0f7fdbce7796f3299cc1dd7752f1091e63132d69fd65a349bcd607777f753bd5e7f3e3f3fbf1a0441e705b6e8b7b17cdfbf086084c7c8d85fc5e572f96b144788c2086114426b8ddca51c00e007000000ffff03003dbae5cc5b37a1a70000000049454e44ae426082";
        if (p.equals("/slider.png")) return "89504e470d0a1a0a0000000d494844520000000c00000010080600000022619e07000000097048597300000b1300000b1301009a9c18000000206348524d00007a25000080830000f9ff000080e9000075300000ea6000003a980000176f925fc546000001b74944415478da7492cf6a535110c67f73ce49ef4d6efeb4b69568c168ed1be8ca9d1b115c0b5de8cea7f12d7c054114576e14442aa89baa858a564d6c6f9a942626f7cf1917b9699b123f18e6709819bef9e693970f079c81050cb350202f32aef814a001548bf7f98621d003fcb4a1065c36622a8291d96a55aff9b81814bb090d591164f5f7d1b7abfdd141c3885500afb9544af5e15a7d63d71849143d7240e84c29faf8e7d5fd6ef4e551b55933eab5202ac4a3a1df8f779fde58bdfb58c92367c4068783cef5da35ddbc73fb41908fa7b427a95476bc7fb775aff3f9fb8b66bdf5c3094606be7b73a9beb2bcf37a9f34c910395d57aca5da58ae1cb8de2dd5d673a778e735bd74f86b883519a8721e7aecc97d7ec593971d20166bf67eb6e79c600a4f335a1311c10059142cb66be53220086626408882907a70614f90b1f3ea3534b50febadf5fec245d7f0d92c256385ac9f407be9932aa9031d3b136e9be3c6b38520dd142b27229d9cae1fbe111b6d2979ea8011c2c0e48b4f92cee82d6870aa2b026446c2af88c4c05f0764408c108a947bf397d604888164eaa5de44228dfe23d308e89e359f2f26f4e7b815209dd2fc3700c242ac4b19438fb90000000049454e44ae426082";
        return null;
    }

    private static int hv(char c) {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        return 0;
    }


    /** thu nho anh (lay mau gan nhat) - MIDP khong co scale san */
    private static Image scale(Image src, int nw, int nh) {
        if (src == null) return null;
        try {
            int ow = src.getWidth(), oh = src.getHeight();
            int[] in = new int[ow * oh];
            src.getRGB(in, 0, ow, 0, 0, ow, oh);
            int[] out = new int[nw * nh];
            for (int y = 0; y < nh; y++) {
                int sy = y * oh / nh;
                for (int x = 0; x < nw; x++) out[y * nw + x] = in[sy * ow + x * ow / nw];
            }
            return Image.createRGBImage(out, nw, nh, true);
        } catch (Throwable e) { return src; }
    }

    public void start(Player p, Lrc l, String t, String a) {
        stop();
        player = p; lrc = l; title = t; artist = a; err = "";
        mode = M_PLAYER; menuSel = 0; lyScroll = 0;
        smoothT = 0; cur = 0; pct = 0; seeking = false; paused = false; holdUntil = 0; lastPos = -1;
        lastC = 1; slideStart = 0; shown = (lrc != null && lrc.n > 0 && lrc.showFrom() == 0);
        armPos = 0;
        lastWall = System.currentTimeMillis();
        long du = 0;
        try { du = p.getDuration(); } catch (Throwable e) {}
        durMs = du > 0 ? (int) (du / 1000) : (l != null ? l.dur : 0);
        try { p.addPlayerListener(this); } catch (Throwable e) { err = "listener loi: " + e; }
        try {
            VolumeControl vc = (VolumeControl) p.getControl("VolumeControl");
            if (vc != null) { vc.setMute(false); vc.setLevel(100); }
        } catch (Throwable e) { err = "volume loi: " + e; }
        try { p.start(); } catch (Throwable e) { err = "START LOI: " + e; }
        running = true;
        new Thread(this).start();
    }

    public void stop() {
        running = false;
        if (player != null) {
            try { player.stop(); } catch (Exception e) {}
            try { player.deallocate(); } catch (Exception e) {}
            try { player.close(); } catch (Exception e) {}
            player = null;
        }
    }

    // ===== updateByTime(t) =====
    private void updateByTime(int t) {
        long now = System.currentTimeMillis();
        if (seeking || now < holdUntil) return;
        if (lrc == null || lrc.n == 0) return;
        cur = lrc.find(t);
        pct = lrc.pct(cur, t);
        // giong ok.js: dong chi hien trong [start, end]; dong dau hien som 3s; dong cuoi to xong thi an
        shown = t >= lrc.showFrom() && !(cur == lrc.n - 1 && pct >= 1000);
        int c = cur < 1 ? 1 : cur;
        if (c != lastC) {                                   // doi cau: sang cau ke tiep thi luot len, con lai nhay thang
            slideStart = (c == lastC + 1) ? now : 0;
            lastC = c;
        }
    }

    // ===== smoothLoop ~60fps =====
    public void run() {
        while (running) {
            long t0 = System.currentTimeMillis();
            try {
                Player p = player;
                if (p != null) {
                    long now = t0;
                    int dt = (int) (now - lastWall); lastWall = now;
                    if (dt < 0 || dt > 200) dt = FRAME_MS;
                    if (durMs <= 0 && now - lastDurChk > 1000) {       // stream: do dai bai co the den tre
                        lastDurChk = now;
                        try { long du = p.getDuration(); if (du > 0) durMs = (int) (du / 1000); } catch (Throwable e) {}
                    }
                    long us = p.getMediaTime();
                    int pos = us >= 0 ? (int) (us / 1000) : smoothT;
                    boolean playing = p.getState() == Player.STARTED;
                    playingNow = playing;
                    if (playing) discAng100 = (discAng100 + dt * 9) % 36000;   // 4s / vong (animation: spin 4s linear)
                    int tgt = playing ? 1000 : 0, mv = dt * 1000 / 700;        // chan kim xoay 0.7s
                    if (armPos < tgt) { armPos += mv; if (armPos > tgt) armPos = tgt; }
                    else if (armPos > tgt) { armPos -= mv; if (armPos < tgt) armPos = tgt; }
                    if (now - lastDbg >= 250) { lastDbg = now; dbg = "st=" + p.getState() + " t=" + (us / 1000); }

                    if (seeking) {
                        if (now >= animStart) {
                            long q = (now - animStart) * 1000 / animDur;
                            pct = (int) (q > 1000 ? 1000 : q);
                        }
                        if (now >= seekEnd) seeking = false;
                    } else if (now - seekedAt < 100) {
                        smoothT = pos; lastPos = pos; updateByTime(pos);
                    } else if (playing) {
                        smoothT += dt;
                        if (pos != lastPos) {
                            lastPos = pos;
                            int e = pos - smoothT;
                            if (e > 500 || e < -500) smoothT = pos; else smoothT += e / 4;
                        }
                        updateByTime(smoothT);
                    } else {
                        smoothT = pos; lastPos = pos; updateByTime(pos);
                    }
                    repaint();
                }
            } catch (Throwable e) { err = "RUN LOI: " + e; try { Thread.sleep(300); } catch (Exception x) {} }
            long used = System.currentTimeMillis() - t0;
            long wait = FRAME_MS - used;
            try { Thread.sleep(wait > 1 ? wait : 1); } catch (Exception e) {}
        }
    }

    // ===== 'seeked' =====
    private void onSeeked(int pos) {
        int idx = lrc.find(pos);
        if (idx > 0 && (pos - lrc.time[idx]) < 250) idx--;
        int remain = lrc.end(idx) - pos; if (remain < 200) remain = 200;
        cur = idx; pct = 0;
        lastC = idx < 1 ? 1 : idx; slideStart = 0;        // tua: doi ngay, khong luot
        shown = pos >= lrc.showFrom();
        smoothT = pos; seekedAt = System.currentTimeMillis();
        if (idx == 0) { seeking = false; holdUntil = 0; updateByTime(pos + 1); }
        else {
            long now = seekedAt;
            holdUntil = now + 300;
            animStart = now + 180; animDur = remain;
            seekEnd = now + (remain > 100 ? remain : 100);
            seeking = true;
        }
        repaint();
    }

    public void playerUpdate(Player p, String ev, Object data) {
        if (PlayerListener.END_OF_MEDIA.equals(ev)) {
            if (repeat && player != null) {
                try {
                    p.setMediaTime(0); p.start();
                    smoothT = 0; lastPos = -1; cur = 0; pct = 0; seeking = false; holdUntil = 0; seekedAt = 0;
                    lastC = 1; slideStart = 0; shown = (lrc != null && lrc.n > 0 && lrc.showFrom() == 0);
                } catch (Exception e) { app.songEnded(); }
            } else app.songEnded();
        } else if (PlayerListener.ERROR.equals(ev)) {
            app.songEnded();
        }
    }

    // ===================== VE =====================
    protected void paint(Graphics g) {
        int w = getWidth(), h = getHeight();
        g.setClip(0, 0, w, h);
        if (mode == M_LYRICS) {
            paintLyricScreen(g, w, h);
            softbar(g, w, h, "", T_BACK);
        } else {
            paintPlayer(g, w, h);
            if (mode == M_MENU) { paintMenu(g, w, h); softbar(g, w, h, T_CHON, T_DONG); }
            else softbar(g, w, h, "Menu", T_BACK);
        }
        if (toast.length() > 0 && System.currentTimeMillis() < toastUntil) paintToast(g, w, h);
    }

    private void paintPlayer(Graphics g, int w, int h) {
        g.setClip(0, 0, w, h);
        g.setColor(0x303030); g.fillRect(0, 0, w, h);

        // thanh tieu de
        grad(g, 0, 32, w);
        g.setFont(fBig); g.setColor(0xFFFFFF);
        g.drawString(T_TITLE, w / 2, 16 - fBig.getHeight() / 2, Graphics.TOP | Graphics.HCENTER);

        // hang icon (repeat: phim 1)
        g.setColor(0x3A3A3A); g.fillRect(0, 32, w, 30);
        Image r = repeat ? imRepOn : imRep;
        if (r != null) g.drawImage(r, 8, 40, TL);
        g.setFont(fSmall); g.setColor(0x888888);
        g.drawString(dbg, w - 6, 32 + (30 - fSmall.getHeight()) / 2, Graphics.TOP | Graphics.RIGHT);

        // anh bia + ten bai + ca si
        paintTurntable(g);
        g.setFont(fBig); g.setColor(0xFFFFFF);
        g.drawString(clip(title, fBig, w - 83), 79, 68, TL);
        g.setFont(fSmall); g.setColor(0xB57FE0);
        g.drawString(clip(artist, fSmall, w - 83), 79, 68 + fBig.getHeight() + 8, TL);

        // *** 3 dong karaoke: dung cho "Dang tai nhac..." ***
        paintLyrics(g, w, 126, h - 128);

        // thoi gian
        int pos = smoothT; if (pos < 0) pos = 0;
        if (durMs > 0 && pos > durMs) pos = durMs;
        int ty = h - 119 - fSmall.getHeight() / 2;
        g.setFont(fSmall); g.setColor(0xFFFFFF);
        g.drawString(mmss(pos), 6, ty, TL);
        g.drawString(durMs > 0 ? mmss(durMs) : "--:--", w - 6, ty, Graphics.TOP | Graphics.RIGHT);

        // thanh tua
        int bx = 3, bw = w - 6, by = h - 101;
        paintBar(g, bx, by, bw);
        if (imKnob != null) {
            int kr = bw - 8 - imKnob.getWidth();
            int kx = bx + 4 + (durMs > 0 ? (int) ((long) kr * pos / durMs) : 0);
            g.drawImage(imKnob, kx, by + 2, TL);
        }

        // hang nut
        int bby = h - 78;
        g.setColor(0x262626); g.fillRect(0, bby, w, 34);
        int sx = (w - 196) / 2;
        long now = System.currentTimeMillis();
        for (int i = 1; i <= 3; i++) {
            int cx = sx + i * 40;
            g.setColor(flashCell == i && now < flashUntil ? 0x777777 : 0x3C3C3C);
            g.fillRect(cx, bby, 36, 34);
            Image im = (i == 1) ? imPrev : (i == 3 ? imNext : (playingNow ? imPause : imPlay));
            if (im != null) g.drawImage(im, cx + (36 - im.getWidth()) / 2, bby + (34 - im.getHeight()) / 2, TL);
        }
    }

    // ===== dia than + chan kim (giong .turntable / .tonearm-unit cua playz8) =====
    // bang sin(0..90 do) * 1000 - CLDC 1.0 khong co Math.sin
    private static final int[] SIN = {0,17,35,52,70,87,105,122,139,156,174,191,208,225,242,259,276,292,309,326,342,358,375,391,407,423,438,454,469,485,500,515,530,545,559,574,588,602,616,629,643,656,669,682,695,707,719,731,743,755,766,777,788,799,809,819,829,839,848,857,866,875,883,891,899,906,914,921,927,934,940,946,951,956,961,966,970,974,978,982,985,988,990,993,995,996,998,999,999,1000,1000};

    private static int isin(int d) {
        d %= 360; if (d < 0) d += 360;
        int sg = 1;
        if (d >= 180) { d -= 180; sg = -1; }
        if (d > 90) d = 180 - d;
        return sg * SIN[d];
    }
    private static int icos(int d) { return isin(d + 90); }

    /** chuan bi anh bia cat tron (chi goi khi doi bai) */
    private void initDisc() { buildDisc(null); }

    public void setCover(Image im) { buildDisc(im); }

    private void buildDisc(Image cover) {
        albumRgb = new int[DD * DD];
        rotBuf = new int[DD * DD];
        rotStep = -1;
        try {
            Image src = null;
            if (cover != null) src = scaleSmooth(cover, DD, DD);
            if (src == null) src = scale(load("/defaultAlbum.png"), DD, DD);
            if (src != null) src.getRGB(albumRgb, 0, DD, 0, 0, DD, DD);
        } catch (Throwable e) {}
        for (int y = 0; y < DD; y++) {
            int dy2 = 2 * y + 1 - DD;
            for (int x = 0; x < DD; x++) {
                int dx2 = 2 * x + 1 - DD;
                albumRgb[y * DD + x] = (dx2 * dx2 + dy2 * dy2 > DD * DD) ? 0 : (albumRgb[y * DD + x] | 0xFF000000);
            }
        }
    }

    /** thu nho co lay trung binh o (box filter) cho anh bia lon -> khong bi rang cua */
    private static Image scaleSmooth(Image src, int nw, int nh) {
        try {
            int ow = src.getWidth(), oh = src.getHeight();
            int[] in = new int[ow * oh];
            src.getRGB(in, 0, ow, 0, 0, ow, oh);
            int[] out = new int[nw * nh];
            for (int y = 0; y < nh; y++) {
                int y0 = y * oh / nh, y1 = (y + 1) * oh / nh; if (y1 <= y0) y1 = y0 + 1;
                for (int x = 0; x < nw; x++) {
                    int x0 = x * ow / nw, x1 = (x + 1) * ow / nw; if (x1 <= x0) x1 = x0 + 1;
                    int r = 0, g = 0, b = 0, n = 0;
                    for (int yy = y0; yy < y1; yy++) for (int xx = x0; xx < x1; xx++) {
                        int p = in[yy * ow + xx];
                        r += (p >> 16) & 255; g += (p >> 8) & 255; b += p & 255; n++;
                    }
                    out[y * nw + x] = 0xFF000000 | ((r / n) << 16) | ((g / n) << 8) | (b / n);
                }
            }
            return Image.createRGBImage(out, nw, nh, false);
        } catch (Throwable e) { return null; }
    }

    /** quay anh bia 'deg' do thuan chieu kim dong ho (lay mau nguoc, nearest) */
    private void rotateDisc(int deg) {
        int co = icos(deg), si = isin(deg), rr = DD * DD;
        for (int y = 0; y < DD; y++) {
            int dy2 = 2 * y + 1 - DD, row = y * DD;
            for (int x = 0; x < DD; x++) {
                int dx2 = 2 * x + 1 - DD;
                if (dx2 * dx2 + dy2 * dy2 > rr) { rotBuf[row + x] = 0; continue; }
                int sx = ((dx2 * co + dy2 * si) / 1000 + DD - 1) >> 1;
                int sy = ((dy2 * co - dx2 * si) / 1000 + DD - 1) >> 1;
                if (sx < 0) sx = 0; else if (sx >= DD) sx = DD - 1;
                if (sy < 0) sy = 0; else if (sy >= DD) sy = DD - 1;
                rotBuf[row + x] = albumRgb[sy * DD + sx];
            }
        }
    }

    private void paintTurntable(Graphics g) {
        final int bx0 = 5, by0 = 62, B = 62;              // o vuong den (130px web -> 62px), giu nguyen vi tri cu
        final int cx = bx0 + B / 2, cy = by0 + B / 2;     // tam mam/dia

        // nen den
        g.setColor(0x000000); g.fillRect(bx0, by0, B, B);

        // mam: vong ngoai xam den, khe den, roi toi dia (ti le tu video: 0.90 / 0.85 / 0.82 canh vuong)
        g.setColor(0x151515); g.fillArc(cx - 28, cy - 28, 56, 56, 0, 360);
        g.setColor(0x050505); g.fillArc(cx - 26, cy - 26, 52, 52, 0, 360);

        // dia quay 4s/vong, dung yen khi pause
        int step = (discAng100 / 100) / 3;
        if (step != rotStep) { rotStep = step; rotateDisc(step * 3); }
        g.drawRGB(rotBuf, 0, DD, cx - DD / 2, cy - DD / 2, DD, DD, true);

        // lo giua dia: den, co anh sang nhe o tren
        g.setColor(0x000000); g.fillArc(cx - 3, cy - 3, 7, 7, 0, 360);
        g.setColor(0x2A2A2A); g.fillArc(cx - 2, cy - 2, 4, 4, 0, 360);
        g.setColor(0x0A0A0A); g.fillArc(cx - 1, cy - 1, 4, 4, 0, 360);

        // ===== kim (ve vao bo dem ARGB, khu rang cua) =====
        for (int i = 0; i < armBuf.length; i++) armBuf[i] = 0;
        final int px = 55, py = 6, L1 = 33, L2 = 4, L3 = 5;      // toa do trong o vuong 62x62
        int x = armPos, x2 = x * x / 1000;
        int sm = 3 * x2 - 2 * (x2 * x / 1000);                  // smoothstep
        int th = 9 - 20 * sm / 1000;                            // +9 do (nhac len) -> -11 do (dat vao dia)
        int t2 = th - 50;                                       // doan cuoi gap xeo ve trai
        int P = 16;                                             // 1 px = 16 don vi
        int pX = px * P + 8, pY = py * P + 8;
        int eX = pX + L1 * P * isin(th) / 1000, eY = pY + L1 * P * icos(th) / 1000;      // khuyu
        int fX = eX + L2 * P * isin(t2) / 1000, fY = eY + L2 * P * icos(t2) / 1000;      // het doan trang
        int hX = fX + L3 * P * isin(t2) / 1000, hY = fY + L3 * P * icos(t2) / 1000;      // het dau kim
        aaLine(armBuf, pX, pY, pX, pY, 5 * P, 0x1C1C1C);        // de truc
        aaLine(armBuf, pX, pY, eX, eY, 16, 0xFFFFFF);           // can dai (rong ~1.5px)
        aaLine(armBuf, eX, eY, fX, fY, 16, 0xFFFFFF);           // doan gap xeo
        aaLine(armBuf, eX, eY, eX, eY, 16, 0xFFFFFF);           // khop noi tron
        aaLine(armBuf, fX, fY, hX, hY, 26, 0x0A0A0A);           // dau kim den (rong ~3px)
        aaLine(armBuf, pX, pY, pX, pY, 40, 0xD2D2D2);           // nut truc
        aaLine(armBuf, pX + 4 * P, pY + 5 * P, pX + 4 * P, pY + 5 * P, 20, 0xFFFFFF);   // cham trang
        g.drawRGB(armBuf, 0, 62, bx0, by0, 62, 62, true);
    }

    private static int isqrt(int n) {
        if (n <= 0) return 0;
        int r = 0, bit = 1 << 28;
        while (bit > n) bit >>= 2;
        while (bit != 0) {
            if (n >= r + bit) { n -= r + bit; r = (r >> 1) + bit; } else r >>= 1;
            bit >>= 2;
        }
        return r;
    }

    /** ve doan thang bo tron co do rong 2*hw (don vi 1/16 px) vao buf 62x62, ria mem (anti-alias), chong len nen */
    private static void aaLine(int[] buf, int x0, int y0, int x1, int y1, int hw, int rgb) {
        final int W = 62;
        int minx = ((x0 < x1 ? x0 : x1) - hw) / 16 - 1, maxx = ((x0 > x1 ? x0 : x1) + hw) / 16 + 1;
        int miny = ((y0 < y1 ? y0 : y1) - hw) / 16 - 1, maxy = ((y0 > y1 ? y0 : y1) + hw) / 16 + 1;
        if (minx < 0) minx = 0; if (miny < 0) miny = 0;
        if (maxx > W - 1) maxx = W - 1; if (maxy > W - 1) maxy = W - 1;
        int dx = x1 - x0, dy = y1 - y0, len2 = dx * dx + dy * dy;
        int sr = (rgb >> 16) & 255, sg = (rgb >> 8) & 255, sb = rgb & 255;
        for (int y = miny; y <= maxy; y++) {
            for (int x = minx; x <= maxx; x++) {
                int qx = x * 16 + 8 - x0, qy = y * 16 + 8 - y0;
                int ex, ey;
                if (len2 == 0) { ex = qx; ey = qy; }
                else {
                    int t = (int) (((long) qx * dx + (long) qy * dy) * 1024 / len2);   // 0..1024
                    if (t < 0) t = 0; else if (t > 1024) t = 1024;
                    ex = qx - dx * t / 1024; ey = qy - dy * t / 1024;
                }
                int d = isqrt(ex * ex + ey * ey);
                int cov = (hw + 8 - d) * 255 / 16;                // 1px do mem o bien
                if (cov <= 0) continue;
                if (cov > 255) cov = 255;
                int dst = buf[y * W + x], da = (dst >>> 24) & 255;
                int oa = cov + da * (255 - cov) / 255;
                int dr = (dst >> 16) & 255, dg = (dst >> 8) & 255, db = dst & 255;
                int r = (sr * cov + dr * da * (255 - cov) / 255) / (oa == 0 ? 1 : oa);
                int gg = (sg * cov + dg * da * (255 - cov) / 255) / (oa == 0 ? 1 : oa);
                int bb = (sb * cov + db * da * (255 - cov) / 255) / (oa == 0 ? 1 : oa);
                buf[y * W + x] = (oa << 24) | (r << 16) | (gg << 8) | bb;
            }
        }
    }

    private void paintLyrics(Graphics g, int w, int zt, int zb) {
        int zh = zb - zt;
        if (err.length() > 0) {
            g.setFont(fSmall); g.setColor(0xFF4444);
            g.drawString(clip(err, fSmall, w - 6), 3, zb - fSmall.getHeight(), TL);
        }
        if (lrc == null || lrc.n == 0) {
            g.setFont(fSmall); g.setColor(0xAAAAAA);
            g.drawString("Khong co loi", w / 2, zt + zh / 2 - fSmall.getHeight() / 2, Graphics.TOP | Graphics.HCENTER);
            return;
        }
        Font F = (3 * fBig.getHeight() + 4 <= zh) ? fBig : fSmall;   // vung hep thi dung font nho
        int fh = F.getHeight();
        int gap = (zh - 3 * fh) / 4; if (gap < 0) gap = 0; if (gap > 5) gap = 5;
        int y0 = zt + (zh - 3 * fh - 2 * gap) / 2; if (y0 < zt) y0 = zt;
        int yc = y0 + fh + gap;                          // hang giua; hang tren = yc - step, hang duoi = yc + step
        int step = fh + gap;
        if (!shown) return;                              // chua toi gio hien loi / hat het bai: khong hien gi

        // luot len khi sang cau moi: ease-out 280ms
        int c = cur < 1 ? 1 : cur;
        int off = 0;
        long el = System.currentTimeMillis() - slideStart;
        boolean sliding = slideStart > 0 && el >= 0 && el < SLIDE_MS;
        if (sliding) {
            int rem = 1000 - (int) (el * 1000 / SLIDE_MS);
            int ease = 1000 - rem * rem / 1000;
            off = step * (1000 - ease) / 1000;
        }

        int cx = g.getClipX(), cy = g.getClipY(), cw = g.getClipWidth(), ch = g.getClipHeight();
        g.clipRect(0, zt, w, zh);                         // dong truot ra/vao bi cat o mep vung loi
        for (int i = c - 2; i <= c + 2; i++) {
            if (i < 0 || i >= lrc.n) continue;
            if (!SHOW_SUNG_LINE && i < cur && !(sliding && i == cur - 1)) continue;
            int y = yc + (i - c) * step + off;
            if (y + fh < zt || y > zb) continue;
            boolean small = i < cur && (y - yc) * 2 <= -step;      // da o nua tren -> chu nho, xam
            if (i == cur) fillLine(g, F, lrc.at(i), w, y, pct, 0xFFFFFF);
            else if (small) plain(g, fSmall, lrc.at(i), w, y + (fh - fSmall.getHeight()) / 2, 0x737373);
            else if (i < cur) fillLine(g, F, lrc.at(i), w, y, 1000, 0xFFFFFF);   // dong vua hat xong: giu 100% mau luc dang truot
            else plain(g, F, lrc.at(i), w, y, 0xFFFFFF);
        }
        g.setClip(cx, cy, cw, ch);
    }

    private void plain(Graphics g, Font f, String s, int w, int y, int color) {
        g.setFont(f); g.setColor(color);
        int tw = f.stringWidth(s);
        g.drawString(s, tw <= w - 6 ? (w - tw) / 2 : 3, y, TL);
    }

    /** chu nen + phan da hat to mau accent #ff284d (width = pct/1000) */
    private void fillLine(Graphics g, Font f, String s, int w, int y, int p, int base) {
        g.setFont(f);
        int tw = f.stringWidth(s), fw = tw * p / 1000, x;
        if (tw <= w - 8) x = (w - tw) / 2;
        else { x = w / 2 - fw; if (x > 4) x = 4; if (x < w - tw - 4) x = w - tw - 4; }
        g.setColor(base); g.drawString(s, x, y, TL);
        int cx = g.getClipX(), cy = g.getClipY(), cw = g.getClipWidth(), ch = g.getClipHeight();
        g.clipRect(x, y, fw, f.getHeight());
        g.setColor(0xFF284D); g.drawString(s, x, y, TL);
        g.setClip(cx, cy, cw, ch);
    }

    /** thanh tua gian theo chieu rong: 2 dau 10px + phan giua lap lai */
    private void paintBar(Graphics g, int bx, int by, int bw) {
        if (imBar == null) return;
        int iw = imBar.getWidth(), ih = imBar.getHeight();
        int x = bx + 10, end = bx + bw - 10;
        while (x < end) {
            int cw = iw - 20; if (cw > end - x) cw = end - x;
            g.setClip(x, by, cw, ih); g.drawImage(imBar, x - 10, by, TL);
            x += cw;
        }
        g.setClip(bx, by, 10, ih); g.drawImage(imBar, bx, by, TL);
        g.setClip(bx + bw - 10, by, 10, ih); g.drawImage(imBar, bx + bw - iw, by, TL);
        g.setClip(0, 0, getWidth(), getHeight());
    }

    /** nen tim gradient cho thanh tren / thanh phim mem */
    private void grad(Graphics g, int y, int h, int w) {
        int d = h > 1 ? h - 1 : 1;
        for (int i = 0; i < h; i++) {
            int q = i * 100 / d;
            int c = (q < 30) ? mix(0x35233F, 0x9A58AA, q * 100 / 30) : mix(0x9A58AA, 0x240A2C, (q - 30) * 100 / 70);
            g.setColor(c);
            g.drawLine(0, y + i, w, y + i);
        }
    }

    private static int mix(int a, int b, int p) {
        int r = (((a >> 16) & 255) * (100 - p) + ((b >> 16) & 255) * p) / 100;
        int gg = (((a >> 8) & 255) * (100 - p) + ((b >> 8) & 255) * p) / 100;
        int bl = ((a & 255) * (100 - p) + (b & 255) * p) / 100;
        return (r << 16) | (gg << 8) | bl;
    }

    private static String mmss(int ms) {
        int s = ms / 1000;
        int m = s / 60; s = s % 60;
        StringBuffer o = new StringBuffer();
        if (m < 10) o.append('0');
        o.append(m).append(':');
        if (s < 10) o.append('0');
        o.append(s);
        return o.toString();
    }

    private String clip(String s, Font f, int w) {
        while (s.length() > 1 && f.stringWidth(s) > w) s = s.substring(0, s.length() - 1);
        return s;
    }

    // ===== phim =====
    protected void keyPressed(int k) {
        if (mode == M_MENU) { menuKey(k); return; }
        if (mode == M_LYRICS) { lyricKey(k); return; }
        if (k == -6 || k == -21) { mode = M_MENU; menuSel = 0; repaint(); return; }   // phim mem trai = Menu
        if (k == -7 || k == -22) { app.songEnded(); return; }                         // phim mem phai = Tro ve
        if (k == KEY_NUM1) { repeat = !repeat; repaint(); return; }
        int ga = 0;
        try { ga = getGameAction(k); } catch (Exception e) {}
        if (ga == FIRE || k == KEY_NUM5) toggle();
        else if (ga == LEFT || k == KEY_NUM4) seek(-5000);
        else if (ga == RIGHT || k == KEY_NUM6) seek(5000);
    }

    protected void keyRepeated(int k) {
        if (mode != M_PLAYER) keyPressed(k);                     // giu phim de cuon / chuyen muc
    }

    // ===================== MENU =====================
    private void menuKey(int k) {
        if (k == -7 || k == -22) { mode = M_PLAYER; repaint(); return; }       // Dong
        if (k == -6 || k == -21) { menuSelect(); return; }                      // Chon
        if (k >= KEY_NUM1 && k <= KEY_NUM5) { menuSel = k - KEY_NUM1; menuSelect(); return; }
        int ga = 0;
        try { ga = getGameAction(k); } catch (Exception e) {}
        if (ga == FIRE) menuSelect();
        else if (ga == UP) { menuSel = (menuSel + MENU.length - 1) % MENU.length; repaint(); }
        else if (ga == DOWN) { menuSel = (menuSel + 1) % MENU.length; repaint(); }
    }

    private void menuSelect() {
        if (menuSel == 0) app.songEnded();                       // Trang chu = ve man nhap ID
        else if (menuSel == 3) { mode = M_LYRICS; lyScroll = 0; repaint(); }   // Loi hat
        else { mode = M_PLAYER; showToast(T_NOSUPPORT); }
    }

    /** bang menu: hang 30px, thanh chon cao 24px (do tu anh chup ZingMp3 240x320) */
    private void paintMenu(Graphics g, int w, int h) {
        int top = 80, bot = h - 34;
        g.setColor(0x303030); g.fillRect(0, top, w, bot - top);
        g.setColor(0x4A4A4A); g.drawLine(0, top, w, top);
        g.setFont(fMenu);
        for (int i = 0; i < MENU.length; i++) {
            int ry = 82 + 30 * i;
            if (i == menuSel) { g.setColor(0x909090); g.fillRect(2, ry, w - 4, 24); }
            g.setColor(0xFFFFFF);
            g.drawString((i + 1) + ". " + MENU[i], 4, ry + 12 - fMenu.getHeight() / 2, TL);
        }
    }

    // ===================== MAN HINH LOI =====================
    public void setLyricText(String s) {
        lyText = (s == null) ? "" : s;
        lyWrap = null; lyScroll = 0;
    }

    private int lineH() { return fMenu.getHeight() + 2; }
    private int viewH() { return getHeight() - 34 - 32 - 8; }

    private void ensureWrap() {
        int tw = getWidth() - 14;
        if (lyWrap == null || lyWrapW != tw) { lyWrap = wrapText(lyText, fMenu, tw); lyWrapW = tw; }
    }

    private void clampScroll() {
        ensureWrap();
        int max = lyWrap.length * lineH() - viewH();
        if (max < 0) max = 0;
        if (lyScroll > max) lyScroll = max;
        if (lyScroll < 0) lyScroll = 0;
    }

    private void lyricKey(int k) {
        if (k == -7 || k == -22) { mode = M_PLAYER; repaint(); return; }       // Tro ve
        int ga = 0;
        try { ga = getGameAction(k); } catch (Exception e) {}
        int step = lineH() * 3;
        if (ga == UP || k == KEY_NUM2) lyScroll -= step;
        else if (ga == DOWN || k == KEY_NUM8) lyScroll += step;
        else if (ga == LEFT || k == KEY_NUM4) lyScroll -= viewH();
        else if (ga == RIGHT || k == KEY_NUM6) lyScroll += viewH();
        else return;
        clampScroll();
        repaint();
    }

    private void paintLyricScreen(Graphics g, int w, int h) {
        g.setColor(0x303030); g.fillRect(0, 0, w, h);
        grad(g, 0, 32, w);
        g.setFont(fBig); g.setColor(0xFFFFFF);
        g.drawString(T_LYRIC, w / 2, 16 - fBig.getHeight() / 2, Graphics.TOP | Graphics.HCENTER);
        int top = 32, bot = h - 34;
        if (lyText.length() == 0) {
            g.setFont(fMenu); g.setColor(0xAAAAAA);
            g.drawString(T_NOLYRIC, w / 2, (top + bot) / 2 - fMenu.getHeight() / 2, Graphics.TOP | Graphics.HCENTER);
            return;
        }
        ensureWrap();
        int lh = lineH();
        g.setClip(0, top, w, bot - top);
        g.setFont(fMenu); g.setColor(0xFFFFFF);
        int y = top + 4 - lyScroll;
        for (int i = 0; i < lyWrap.length; i++, y += lh) {
            if (y + lh < top) continue;
            if (y > bot) break;
            g.drawString(lyWrap[i], 6, y, TL);
        }
        g.setClip(0, 0, w, h);
        int total = lyWrap.length * lh, vh = bot - top - 8;
        if (total > vh) {                                          // thanh cuon
            int max = total - vh;
            int th = vh * vh / total; if (th < 8) th = 8;
            int ty = top + 4 + (vh - th) * lyScroll / max;
            g.setColor(0x444444); g.fillRect(w - 5, top + 4, 3, vh);
            g.setColor(0xB57FE0); g.fillRect(w - 5, ty, 3, th);
        }
    }

    /** cat chu theo chieu rong, giu xuong dong cua loi */
    private String[] wrapText(String s, Font f, int w) {
        Vector v = new Vector();
        int st = 0;
        for (int i = 0; i <= s.length(); i++) {
            if (i == s.length() || s.charAt(i) == '\n') {
                wrapLine(s.substring(st, i), f, w, v);
                st = i + 1;
            }
        }
        String[] a = new String[v.size()];
        v.copyInto(a);
        return a;
    }

    private void wrapLine(String line, Font f, int w, Vector out) {
        line = line.trim();
        if (line.length() == 0) { out.addElement(""); return; }
        while (f.stringWidth(line) > w) {
            int cut = line.length();
            while (cut > 1 && f.stringWidth(line.substring(0, cut)) > w) cut--;
            int sp = line.lastIndexOf(' ', cut);
            if (sp <= 0) sp = cut;
            out.addElement(line.substring(0, sp).trim());
            line = line.substring(sp).trim();
            if (line.length() == 0) return;
        }
        out.addElement(line);
    }

    private void softbar(Graphics g, int w, int h, String l, String r) {
        grad(g, h - 34, 34, w);
        g.setFont(fBig); g.setColor(0xFFFFFF);
        int sy = h - 34 + (34 - fBig.getHeight()) / 2;
        g.drawString(l, 6, sy, TL);
        g.drawString(r, w - 6, sy, Graphics.TOP | Graphics.RIGHT);
    }

    private void showToast(String s) { toast = s; toastUntil = System.currentTimeMillis() + 1500; repaint(); }

    private void paintToast(Graphics g, int w, int h) {
        g.setFont(fSmall);
        int tw = fSmall.stringWidth(toast) + 16, th = fSmall.getHeight() + 10;
        int x = (w - tw) / 2, y = h - 34 - th - 12;
        g.setColor(0x000000); g.fillRect(x, y, tw, th);
        g.setColor(0xFFFFFF); g.drawString(toast, x + 8, y + 5, TL);
    }

    private void flash(int cell) { flashCell = cell; flashUntil = System.currentTimeMillis() + 150; }

    private void toggle() {
        try {
            if (player == null) return;
            flash(2);
            if (player.getState() != Player.STARTED) { player.start(); paused = false; }
            else { player.stop(); paused = true; int pos = (int) (player.getMediaTime() / 1000); smoothT = pos; updateByTime(pos); }
            repaint();
        } catch (Exception e) {}
    }

    private void seek(int ms) {
        try {
            if (player == null) return;
            long t = player.getMediaTime() / 1000 + ms;
            if (t < 0) t = 0;
            if (durMs > 0 && t > durMs - 500) t = (durMs - 500 > 0) ? durMs - 500 : 0;
            player.setMediaTime(t * 1000);
            flash(ms < 0 ? 1 : 3);
            if (lrc != null && lrc.n > 0) onSeeked((int) t);
            else { smoothT = (int) t; lastPos = -1; seekedAt = System.currentTimeMillis(); }
            repaint();
        } catch (Exception e) {}
    }
}
