@echo off
rem === Sua 2 dong nay cho dung may ban ===
set WTK=C:\WTK2.5.2
set JAVAC=javac
rem (JAVAC phai la JDK 1.6/1.7/1.8 - JDK moi hon khong ho tro -source 1.3)

set LIBS=%WTK%\lib\cldcapi10.jar;%WTK%\lib\midpapi20.jar;%WTK%\lib\mmapi.jar
if exist tmp rmdir /s /q tmp
mkdir tmp\classes tmp\pre out
%JAVAC% -source 1.3 -target 1.1 -bootclasspath %LIBS% -d tmp\classes src\Api.java src\Lrc.java src\Net.java src\KaraokeCanvas.java src\KaraokeMidlet.java || goto :err
"%WTK%\bin\preverify" -classpath %LIBS% -d tmp\pre tmp\classes || goto :err
jar cvfm out\KaraokeNCT.jar MANIFEST.MF -C tmp\pre . -C res . || goto :err
echo.
echo XONG: out\KaraokeNCT.jar
goto :eof
:err
echo LOI BUILD
