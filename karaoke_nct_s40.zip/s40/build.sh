#!/bin/sh
# Sua WTK cho dung duong dan (can JDK 1.6-1.8)
WTK=${WTK:-$HOME/WTK2.5.2}
LIBS=$WTK/lib/cldcapi10.jar:$WTK/lib/midpapi20.jar:$WTK/lib/mmapi.jar
set -e
rm -rf tmp; mkdir -p tmp/classes tmp/pre out
javac -source 1.3 -target 1.1 -bootclasspath "$LIBS" -d tmp/classes src/Api.java src/Lrc.java src/Net.java src/KaraokeCanvas.java src/KaraokeMidlet.java
"$WTK/bin/preverify" -classpath "$LIBS" -d tmp/pre tmp/classes
jar cvfm out/KaraokeNCT.jar MANIFEST.MF -C tmp/pre . -C res .
echo "XONG: out/KaraokeNCT.jar"
