APP GOI THANG: https://mp3.duyquyen.site/api/test.php?id=<ID>   (sua trong src/Api.java: URL, ID_PARAM, STREAM_PROXY)
- Loi NCT (hex RC4, key "Lyr1cjust4nct") duoc giai ma ngay trong app (Api.java) -> khong can m.php nua.
- Nhac: lay link "128" trong JSON, doi https -> http de S40 cu phat duoc. Neu van khong phat: dung STREAM_PROXY.
- Build: MIDP 2.0 + CLDC 1.0, nap 5 file src/: Api, Lrc, Net, KaraokeCanvas, KaraokeMidlet.
- Dung: nhap ID -> PHAT NHAC. Karaoke: giua = pause/play, trai/phai = tua 5s, Quay lai = ve man nhap ID.
(server/m.php la ban cu, khong con dung; da sua key giai ma thanh Lyr1cjust4nct.)

BUILD JAR: sua duong dan WTK trong build.bat (Windows) hoac build.sh, chay -> out/KaraokeNCT.jar
  (can WTK 2.5.2 hoac bo CLDC1.0 + MIDP2.0 + MMAPI + preverify, va JDK 1.6-1.8)
  Hoac NetBeans/Eclipse: tao MIDlet project MIDP2.0/CLDC1.0, bo 5 file src/ vao, Build.
