@echo off
rem === Chay 1 lan: doi map/model/am thanh CS 1.6 sang dinh dang dien thoai -> thu muc res\ ===
rem Sua dong nay: thu muc co cstrike va valve (Steam: ...\steamapps\common\Half-Life)
set CS16_GAME=C:\Program Files (x86)\Steam\steamapps\common\Half-Life
set PYTHONIOENCODING=utf-8
set MAPS=de_dust2 de_dust de_train

rem can: pip install numpy pillow
mkdir res\snd 2>nul
python conv\conv_map.py res %MAPS% || goto :err
python conv\conv_nav.py res %MAPS% || goto :err
python conv\conv_snd.py res\snd || goto :err
python conv\conv_hud.py res || goto :err
python conv\conv_mdl3d.py || goto :err
python conv\conv_ui.py || goto :err
python conv\bake.py res pl:terror:ak47:t pl:gign:m4a1:ct || goto :err
echo XONG convert. Gio chay build.bat
goto :eof
:err
echo LOI CONVERT
