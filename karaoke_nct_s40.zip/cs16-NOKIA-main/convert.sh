#!/bin/sh
# Chay 1 lan: doi map/model/am thanh CS 1.6 sang dinh dang dien thoai -> thu muc res/
# Dung: CS16_GAME=/duong/dan/Half-Life ./convert.sh   (can: pip install numpy pillow)
: "${CS16_GAME:?dat CS16_GAME=thu muc co cstrike va valve}"
export CS16_GAME PYTHONIOENCODING=utf-8
MAPS="de_dust2 de_dust de_train"
set -e
mkdir -p res/snd
python3 conv/conv_map.py res $MAPS
python3 conv/conv_nav.py res $MAPS
python3 conv/conv_snd.py res/snd
python3 conv/conv_hud.py res
python3 conv/conv_mdl3d.py
python3 conv/conv_ui.py
python3 conv/bake.py res pl:terror:ak47:t pl:gign:m4a1:ct
echo "XONG convert. Gio chay ./build.sh"
