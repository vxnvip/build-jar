#!/bin/sh
# Sua WTK cho dung duong dan (can JDK 1.6-1.8, hoac dat ECJ=/duong/dan/ecj-4.6.1.jar)
WTK=${WTK:-$HOME/WTK2.5.2}
LIBS=$WTK/lib/cldcapi11.jar:$WTK/lib/midpapi20.jar:$WTK/lib/mmapi.jar
set -e
[ -f res/de_dust2.cse ] || { echo "CHUA CONVERT: chay ./convert.sh truoc"; exit 1; }
rm -rf tmp; mkdir -p tmp/classes tmp/pre tmp/res out
ls src/core/cs/*.java src/midp/cs/midp/*.java > tmp/src.txt
if [ -z "$ECJ" ]; then
  javac -source 1.3 -target 1.1 -nowarn -encoding UTF-8 -bootclasspath "$LIBS" -d tmp/classes @tmp/src.txt
else
  java -jar "$ECJ" -source 1.3 -target 1.3 -nowarn -encoding UTF-8 -bootclasspath "$LIBS" -d tmp/classes @tmp/src.txt
fi
"$WTK/bin/preverify" -classpath "$LIBS" -d tmp/pre tmp/classes
# tai nguyen phai nam o goc file jar (khong co thu muc con)
for p in res/*.cse res/*.nv res/t.pls res/ct.pls res/*.m3 res/*.a3 res/mdltex.bin res/*.fnt res/hud.bin res/icon.png res/sky_*.png res/ui_*.png res/snd/*.wav; do
  [ -f "$p" ] && cp "$p" tmp/res/
done
[ -f tmp/res/icon.png ] || { echo "THIEU res/icon.png"; exit 1; }
jar cfm out/CS16_E52.jar MANIFEST.MF -C tmp/pre . -C tmp/res .
echo "XONG: out/CS16_E52.jar"
echo "(tuy chon) tao .jad + .sisx:  python3 tools/sis_from_jar.py"
