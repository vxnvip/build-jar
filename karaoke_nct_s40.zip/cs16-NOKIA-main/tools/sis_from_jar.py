# (tuy chon) out/CS16_E52.jar -> .jad + .sisx da ky (tools/build_sis.py doc build/CS16_E52.jar + .jad)
import os, shutil, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT); sys.path.insert(0, 'tools')
import rsa1
os.makedirs('build', exist_ok=True)
shutil.copy('out/CS16_E52.jar', 'build/CS16_E52.jar')
size = os.path.getsize('build/CS16_E52.jar')
open('build/CS16_E52.jad', 'w', encoding='utf-8').write(
    'MIDlet-1: CS 1.6,/icon.png,cs.midp.CSMidlet\nMIDlet-Name: CS16E52\nMIDlet-Vendor: E52 Edition\nMIDlet-Version: 1.1.0\n'
    'MIDlet-Jar-URL: CS16_E52.jar\nMIDlet-Jar-Size: %d\nMicroEdition-Configuration: CLDC-1.1\nMicroEdition-Profile: MIDP-2.0\n'
    'Nokia-MIDlet-Category: Game\n' % size)
rsa1.ensure('cert/cs16e52_key.pem', 'cert/cs16e52_cert.pem')
exec(open('tools/build_sis.py').read())
for f in ('CS16_E52.jad', 'CS16_E52.sisx'): shutil.copy('build/' + f, 'out/' + f)
print('XONG: out/CS16_E52.jad, out/CS16_E52.sisx')
