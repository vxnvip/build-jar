@echo off
rem === Sua 2 dong nay cho dung may ban ===
set WTK=C:\WTK2.5.2
set JAVAC=javac
rem (JAVAC phai la JDK 1.6/1.7/1.8. JDK moi hon khong ho tro -source 1.3.
rem  Neu chi co JDK moi: tai ecj-4.6.1.jar roi dat ECJ=duong\dan\ecj-4.6.1.jar o dong duoi)
set ECJ=

rem === Truoc khi build phai chay convert.bat 1 lan (tao thu muc res\ tu CS 1.6 cua ban) ===
if not exist res\de_dust2.cse (echo CHUA CONVERT: chay convert.bat truoc & goto :err)

set LIBS=%WTK%\lib\cldcapi11.jar;%WTK%\lib\midpapi20.jar;%WTK%\lib\mmapi.jar
if exist tmp rmdir /s /q tmp
mkdir tmp\classes tmp\pre tmp\res out
if exist tmp\src.txt del tmp\src.txt
for %%f in (src\core\cs\*.java src\midp\cs\midp\*.java) do echo %%f>>tmp\src.txt

if "%ECJ%"=="" (
  %JAVAC% -source 1.3 -target 1.1 -nowarn -encoding UTF-8 -bootclasspath %LIBS% -d tmp\classes @tmp\src.txt || goto :err
) else (
  java -jar "%ECJ%" -source 1.3 -target 1.3 -nowarn -encoding UTF-8 -bootclasspath %LIBS% -d tmp\classes @tmp\src.txt || goto :err
)
"%WTK%\bin\preverify" -classpath %LIBS% -d tmp\pre tmp\classes || goto :err

rem tai nguyen phai nam o goc file jar (khong co thu muc con)
for %%p in (res\*.cse res\*.nv res\t.pls res\ct.pls res\*.m3 res\*.a3 res\mdltex.bin res\*.fnt res\hud.bin res\icon.png res\sky_*.png res\ui_*.png res\snd\*.wav) do copy /y "%%p" tmp\res >nul
if not exist tmp\res\icon.png (echo THIEU res\icon.png & goto :err)

jar cvfm out\CS16_E52.jar MANIFEST.MF -C tmp\pre . -C tmp\res . >nul || goto :err
echo.
echo XONG: out\CS16_E52.jar
echo (tuy chon) tao .jad + .sisx:  python tools\sis_from_jar.py
goto :eof
:err
echo LOI BUILD
